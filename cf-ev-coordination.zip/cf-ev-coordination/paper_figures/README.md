# paper_figures — recorded outputs and figure scripts

`src_*.txt` are the text outputs of the runs reported in the paper, copied unchanged from the cluster (shell prompts
removed). `data.py` parses them and cross-checks them against each other (`python data.py` prints the check result);
`figs.py` redraws Figs. 1–9 into `figs/`. `eqnums.json` holds the equation numbers printed inside Figs. 1–2.

| File | Produced by |
|---|---|
| `src_dev.txt` | `slurm/02_oracle_dev.slurm` (development check) |
| `src_gate_D0.txt` | `slurm/03_oracle_test.slurm` (decision rule 1, D0) |
| `src_robust.txt` | `slurm/04_stress_models.slurm` |
| `src_jit_tableA.txt` | `slurm/05_jit_and_obedience.slurm` |
| `src_tableA_v2_mech.txt` | `slurm/06_nominal_and_mechanism.slurm` |
| `src_nominal_pairs.txt`, `src_mech_v2.txt` | `slurm/08_analysis.sh` |
| `src_dataset.txt` | `slurm/07_counterfactual_dataset.slurm` |
