"""All manuscript figures. Data figures read only from data.py (parsed cluster outputs); Figs. 1-2 are schematics."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Patch
from matplotlib.lines import Line2D
import numpy as np
import data as Dt

plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Liberation Serif', 'TeX Gyre Termes', 'DejaVu Serif'],
                     'font.size': 9, 'axes.titlesize': 9.5, 'axes.labelsize': 9, 'legend.fontsize': 8,
                     'xtick.labelsize': 8, 'ytick.labelsize': 8, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.edgecolor': '#5c5b57', 'axes.linewidth': 0.8, 'xtick.color': '#3d3c39', 'ytick.color': '#3d3c39',
                     'axes.grid': True, 'grid.color': '#e4e3df', 'grid.linewidth': 0.6, 'axes.axisbelow': True,
                     'savefig.dpi': 300, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.04})
C = dict(oracle='#2a78d6', nominal='#1baf7a', jit='#eb6834', pace='#6250d6', reactive='#8a8983', ink='#1b1b1a', quiet='#5c5b57')
NAME = dict(oracle='Oracle (ceiling)', nominal='Nominal (deployable)', jit='JIT-12', pace='PACE-EVA')
LBL = dict(D0='D0', A='A', B='B', C='C', D='D', L='L', O20='O20', O40='O40')
import json, os
OUT = 'figs/'; os.makedirs(OUT, exist_ok=True)
import json, os
EQ = json.load(open('eqnums.json')) if os.path.exists('eqnums.json') else {}
def q(*labels):
    n = [EQ.get(l, '?') for l in labels]
    return '(' + ')-('.join(str(x) for x in ([n[0], n[-1]] if len(n) > 1 else n)) + ')'


def save(fig, name):
    fig.savefig(OUT + name + '.png'); fig.savefig(OUT + name + '.pdf'); plt.close(fig)


# ------------------------------------------------------------------------------------------- Fig. 1 framework
def fig_framework():
    fig, ax = plt.subplots(figsize=(7.2, 3.6)); ax.set_xlim(0, 100); ax.set_ylim(6, 61); ax.axis('off')
    W, H = 23.0, 15.5
    boxes = [  # (x, y, stage, title, lines, accent)
        (0.5, 43, 'Stage 1', 'Real traffic', ['nuScenes, 2 Hz boxes', 'resampled to 0.1 s ' + q('resample'), 'held-out val = test set'], False),
        (25.6, 43, 'Stage 2', 'Path frame', ['EV reference path', 'Frenet projection s, d ' + q('frenet'), 'corridor |d| < 2.6 m ' + q('corridor')], False),
        (50.7, 43, 'Stage 3', 'Reactive replay', ['EV with IDM ' + q('idm', 'evkin'), 'hidden driver traits ' + q('traits', 'yieldshare'), 'yield, freeze, follow ' + q('aware', 'ydir')], False),
        (75.8, 43, 'Stage 4', 'Connectivity', ['CVs with rate ρ ' + q('cv'), r'candidate set $C_k$', 'commands, obedience ' + q('obey')], False),
        (75.8, 22, 'Stage 5', 'Counterfactual copy', [r'exact copy of state $x_k$ ' + q('fork'), 'apply action a, run H s', 'paired outcomes Y(a) ' + q('effect')], True),
        (50.7, 22, 'Stage 6', 'Coordinators', ['oracle: true traits ' + q('oracle'), 'nominal: sampled traits ' + q('nominal'), 'baselines ' + q('broadcast', 'pace')], True),
        (25.6, 22, 'Stage 7', 'Evaluation', ['delay, metres lost ' + q('delay', 'lost'), 'conflicts, commands ' + q('conflict', 'counts'), 'paired bootstrap ' + q('pdiff', 'recovery')], False),
        (0.5, 22, 'Stage 8', 'Results', ['ceiling, 16 conditions', 'decomposition, mechanism', 'counterfactual dataset'], False)]
    centers = []
    for x, y, st, ti, ls, acc in boxes:
        ec = C['oracle'] if acc else '#8a8983'
        ax.add_patch(FancyBboxPatch((x, y), W, H, boxstyle='round,pad=0.3,rounding_size=1.2', fc='#eaf2fc' if acc else 'white', ec=ec, lw=1.4 if acc else 1.0))
        ax.text(x + 1.2, y + H - 2.3, st, fontsize=7.5, color=C['quiet'], va='center')
        ax.text(x + 1.2, y + H - 5.4, ti, fontsize=9.2, fontweight='bold', color=C['ink'], va='center')
        for i, l in enumerate(ls): ax.text(x + 1.2, y + H - 8.8 - 2.6 * i, l, fontsize=7.0, color=C['ink'], va='center')
        centers.append((x, y))
    def arr(p, q): ax.add_patch(FancyArrowPatch(p, q, arrowstyle='-|>', mutation_scale=10, lw=1.1, color='#5c5b57'))
    for i in range(3): arr((boxes[i][0] + W + 0.4, 43 + H / 2), (boxes[i + 1][0] - 0.4, 43 + H / 2))
    arr((75.8 + W / 2, 43 - 0.4), (75.8 + W / 2, 22 + H + 0.4))
    for i in range(4, 7): arr((boxes[i][0] - 0.4, 22 + H / 2), (boxes[i + 1][0] + W + 0.4, 22 + H / 2))
    # loop between coordinator and copies
    ax.add_patch(FancyArrowPatch((50.7 + W - 3, 22 - 0.6), (75.8 + 3, 22 - 0.6), connectionstyle='arc3,rad=0.45', arrowstyle='-|>', mutation_scale=9, lw=1.0, color=C['oracle']))
    ax.text(63.5, 12.4, 'every 0.5 s: try each action in a copy,\nscore it with J(a) ' + q('cost') + ', apply the best', fontsize=7.4, ha='center', color=C['oracle'])
    ax.text(0.5, 8.2, 'Numbers in parentheses refer to the equations in Section 3; blue stages are the counterfactual part added in this work.', fontsize=7.4, color=C['quiet'])
    save(fig, 'fig1_framework')


# ------------------------------------------------------------------------------------------- Fig. 2 branching schematic
def fig_branching():
    fig, ax = plt.subplots(figsize=(7.0, 3.0)); ax.set_xlim(0, 100); ax.set_ylim(0, 44); ax.axis('off')
    ax.plot([4, 30], [22, 22], color=C['ink'], lw=2.0)
    ax.text(4, 24.0, 'logged replay to step k', fontsize=7.8, color=C['ink'])
    ax.scatter([30], [22], s=40, color=C['ink'], zorder=5); ax.text(28.5, 18.0, r'state $x_k$', fontsize=8.5, ha='right')
    names = [r'$a_0$: no command', r'$a_1$: command $j_1$', r'$a_2$: command $j_2$', r'$a_{\mathrm{all}}$: command all of $C_k$']
    ys = [38, 28, 16, 6]; Js = ['J = 12.4', 'J = 9.1', 'J = 10.8', 'J = 11.6']
    for i, (n, y) in enumerate(zip(names, ys)):
        best = i == 1
        xs = np.linspace(30, 78, 40); yy = 22 + (y - 22) * (1 - np.exp(-(xs - 30) / 9))
        ax.plot(xs, yy, color=C['oracle'] if best else '#8a8983', lw=2.0 if best else 1.2, ls='-' if best else (0, (4, 2)))
        ax.text(79.5, y, n, fontsize=7.8, va='center', color=C['ink'])
        ax.text(66, y + 1.8, Js[i], fontsize=7.2, color=C['oracle'] if best else C['quiet'], ha='center')
    ax.annotate('', xy=(78, 41.5), xytext=(30, 41.5), arrowprops=dict(arrowstyle='<->', color=C['quiet'], lw=0.8))
    ax.text(54, 42.6, 'each copy runs H = 15 s ahead (no further commands)', fontsize=7.4, ha='center', color=C['quiet'])
    ax.text(4, 2.0, 'Schematic. The J values are illustrative, not measured; the copy with the lowest cost J (blue) is applied to the real replay.', fontsize=7.2, color=C['quiet'])
    save(fig, 'fig2_branching')


# ------------------------------------------------------------------------------------------- Fig. 3 development check
def fig_dev():
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.5), gridspec_kw=dict(width_ratios=[1.15, 1, 1]))
    T = [2, 4, 6, 8, 12]; J = [Dt.JIT[f'jit{t}']['J'] for t in T]
    a = axs[0]; a.plot(T, J, marker='o', color=C['jit'], lw=1.6, ms=5)
    a.axhline(Dt.JIT['reactive']['J'], color=C['reactive'], ls='--', lw=1.1)
    a.text(2.2, Dt.JIT['reactive']['J'] - 1.6, f"reactive broadcast ({Dt.JIT['reactive']['J']:.2f})", fontsize=7.4, color=C['quiet'])
    for t, j in zip(T, J): a.text(t, j + 0.8, f'{j:.2f}', fontsize=7, ha='center', color=C['ink'])
    a.set_xlabel('JIT trigger time T (s)'); a.set_ylabel('Selection cost, Eq. ' + q('jitsel')); a.set_xticks(T)
    a.set_title(f'(a) JIT selection, {Dt.JIT_N} dev. replays', loc='left'); a.set_ylim(110, 128)
    keys = [('oracle_l0_H8_nocoord', 'λ=0, H=8'), ('oracle_l0.25_H8_nocoord', 'λ=0.25, H=8'), ('oracle_l1_H8_nocoord', 'λ=1, H=8'),
            ('oracle_l0_H15_nocoord', 'λ=0, H=15'), ('oracle_l0.25_H15_nocoord', 'λ=0.25, H=15'), ('oracle_l1_H15_nocoord', 'λ=1, H=15'), ('pace_eva', 'PACE-EVA')]
    for ai, (m, lab) in enumerate([('d', 'EV delay difference (s)'), ('l', 'Metres lost difference (m)')]):
        a = axs[ai + 1]
        for i, (k, nm) in enumerate(keys):
            v = Dt.DEV_DIFF[k][m]; col = C['pace'] if k == 'pace_eva' else C['oracle']
            prim = k == 'oracle_l0.25_H15_nocoord'
            a.errorbar(v[0], i, xerr=[[v[0] - v[1]], [v[2] - v[0]]], fmt='D' if prim else 'o', color=col, ms=5 if prim else 4, capsize=2, lw=1.1,
                       mfc=col if prim else 'white')
        a.axvline(0, color=C['quiet'], lw=0.9); a.set_yticks(range(len(keys)))
        a.set_yticklabels([n for _, n in keys] if ai == 0 else [''] * len(keys)); a.invert_yaxis(); a.set_xlabel(lab)
        a.set_title('(b) vs. broadcast, EV delay' if ai == 0 else '(c) vs. broadcast, metres lost', loc='left'); a.grid(axis='y', visible=False)
    fig.text(0.40, -0.06, f'(b), (c): {Dt.DEV_N["replays"]} development replays ({Dt.DEV_N["scenes"]} scenes), ρ = 0.5, mean and 95% scene-bootstrap interval; filled diamond = primary oracle.', fontsize=7.2, color=C['quiet'])
    fig.tight_layout(w_pad=0.6); save(fig, 'fig3_dev')


# ------------------------------------------------------------------------------------------- Fig. 4 default model across rho
def fig_rho():
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.4))
    rhos = ['0.25', '0.5', '1.0']; x = np.arange(3)
    for ai, (m, ylab) in enumerate([('d', 'EV delay difference (s)'), ('l', 'Civilian metres lost difference (m)')]):
        a = axs[ai]
        for off, nm, src in [(-0.09, 'oracle', Dt.GATE), (0.09, 'pace', Dt.PACE0)]:
            v = np.array([src[r][m] for r in rhos])
            a.errorbar(x + off, v[:, 0], yerr=[v[:, 0] - v[:, 1], v[:, 2] - v[:, 0]], fmt='o', color=C[nm], ms=5, capsize=3, lw=1.3, label=NAME[nm])
            for xi, vi in zip(x + off, v[:, 0]): a.text(xi + 0.05, vi, f'{vi:+.2f}' if m == 'd' else f'{vi:+.1f}', fontsize=7, va='center', color=C[nm])
        a.axhline(0, color=C['quiet'], lw=0.9); a.set_xticks(x); a.set_xticklabels([f'ρ = {r}' for r in rhos]); a.set_ylabel(ylab)
        a.set_title('(a) EV delay' if ai == 0 else '(b) Civilian metres lost', loc='left'); a.grid(axis='x', visible=False); a.set_xlim(-0.4, 2.6)
    axs[0].legend(frameon=False, loc='lower left')
    fig.text(0.02, -0.07, f'Default driver model D0, {Dt.HEAD["n"]} test replays per ρ; difference to the reactive broadcast, mean and 95% scene-bootstrap interval (below zero = better).', fontsize=7.2, color=C['quiet'])
    fig.tight_layout(); save(fig, 'fig4_rho')


# ------------------------------------------------------------------------------------------- Fig. 5 all coordinators, all conditions
def fig_all():
    fig, axs = plt.subplots(2, 2, figsize=(7.2, 5.0), sharex=True)
    meths = ['oracle', 'nominal', 'jit', 'pace']; x = np.arange(len(Dt.MODELS)); w = 0.2
    for ci_, rho in enumerate(Dt.RHOS):
        for ri, (m, sk, ylab) in enumerate([('d', 'd_sig', 'EV delay difference (s)'), ('p', 'p_sig', 'Metres lost difference (%)')]):
            a = axs[ri, ci_]
            for k, mt in enumerate(meths):
                vals = [Dt.TAB[(mo, rho)][mt][m] for mo in Dt.MODELS]; sig = [Dt.TAB[(mo, rho)][mt][sk] for mo in Dt.MODELS]
                for xi, v, s in zip(x + (k - 1.5) * w, vals, sig):
                    a.bar(xi, v, w * 0.92, color=C[mt] if s else 'white', edgecolor=C[mt], lw=1.0, hatch=None if s else '////')
            a.axhline(0, color=C['quiet'], lw=0.9); a.grid(axis='x', visible=False)
            a.set_title(f'({"abcd"[ri * 2 + ci_]}) {"EV delay" if m == "d" else "Civilian metres lost"}, ρ = {rho}', loc='left')
            if ci_ == 0: a.set_ylabel(ylab)
            a.set_xticks(x); a.set_xticklabels([LBL[mo] for mo in Dt.MODELS])
    hs = [Patch(fc=C[mt], ec=C[mt], label=NAME[mt]) for mt in meths] + [Patch(fc='white', ec='#5c5b57', hatch='////', label='95% CI includes 0')]
    fig.legend(handles=hs, loc='upper center', ncol=5, frameon=False, bbox_to_anchor=(0.5, 1.03))
    fig.text(0.02, -0.02, 'Mean paired difference to the reactive broadcast on the test scenes (332–336 replays per condition); below zero = better.', fontsize=7.2, color=C['quiet'])
    fig.tight_layout(rect=(0, 0, 1, 0.97)); save(fig, 'fig5_all')


# ------------------------------------------------------------------------------------------- Fig. 6 oracle minus baselines (forest)
def fig_forest():
    conds = [(mo, rho) for rho in Dt.RHOS for mo in Dt.MODELS]
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 4.0), sharey=True)
    y = np.arange(len(conds))
    for ai, (m, lab) in enumerate([('d', 'Oracle minus baseline, EV delay (s)'), ('l', 'Oracle minus baseline, metres lost (m)')]):
        a = axs[ai]
        for off, key, nm in [(-0.16, 'o_minus_jit', 'jit'), (0.16, 'o_minus_pace', 'pace')]:
            v = np.array([Dt.TAB[c][key][m] for c in conds])
            a.errorbar(v[:, 0], y + off, xerr=[v[:, 0] - v[:, 1], v[:, 2] - v[:, 0]], fmt='o', ms=3.8, capsize=1.8, lw=1.0, color=C[nm], label=f'vs. {NAME[nm]}')
        a.axvline(0, color=C['quiet'], lw=0.9); a.set_xlabel(lab); a.grid(axis='y', visible=False)
        a.axhline(7.5, color='#c9c8c3', lw=0.8)
        a.set_title('(a) EV delay' if ai == 0 else '(b) Civilian metres lost', loc='left')
    axs[0].set_yticks(y); axs[0].set_yticklabels([f'{mo}, ρ={rho}' for mo, rho in conds]); axs[0].invert_yaxis()
    axs[1].legend(frameon=False, loc='lower left')
    fig.text(0.02, -0.04, 'Mean and 95% scene-bootstrap interval of the paired difference on the test scenes; every interval lies below zero.', fontsize=7.2, color=C['quiet'])
    fig.tight_layout(); save(fig, 'fig6_forest')


# ------------------------------------------------------------------------------------------- Fig. 7 nominal: decomposition + never slower
def fig_nominal():
    conds = [(mo, rho) for rho in Dt.RHOS for mo in Dt.MODELS]
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.6), gridspec_kw=dict(width_ratios=[1, 1.15]))
    a = axs[0]; y = np.arange(len(conds)); sh = [Dt.TAB[c]['rec_lost'] for c in conds]
    a.barh(y, sh, color=C['nominal'], height=0.62); a.barh(y, [100 - s for s in sh], left=sh, color='#e4e3df', height=0.62)
    for yi, s in zip(y, sh): a.text(s - 1.5, yi, f'{s}%', ha='right', va='center', fontsize=7, color='white')
    a.set_yticks(y); a.set_yticklabels([f'{mo}, ρ={rho}' for mo, rho in conds]); a.invert_yaxis(); a.set_xlim(0, 100)
    a.set_xlabel("Share of the oracle's reduction in metres lost (%)"); a.grid(axis='y', visible=False); a.axhline(7.5, color='white', lw=2)
    a.set_title('(a) Recovered by the population model', loc='left')
    a.legend(handles=[Patch(fc=C['nominal'], label='recovered by nominal'), Patch(fc='#e4e3df', label='needs individual knowledge')], frameon=False, loc='upper center', fontsize=7, ncol=2, bbox_to_anchor=(0.5, -0.16))
    a = axs[1]
    for off, key, nm, col in [(-0.22, 'reactive', 'broadcast', C['reactive']), (0.0, 'jit', 'JIT-12', C['jit']), (0.22, 'pace', 'PACE-EVA', C['pace'])]:
        v = np.array([Dt.NOMP[c][key]['d'] for c in conds])
        a.errorbar(v[:, 0], y + off, xerr=[v[:, 0] - v[:, 1], v[:, 2] - v[:, 0]], fmt='o', ms=3.4, capsize=1.6, lw=0.9, color=col, label=f'nominal − {nm}')
    a.axvline(0, color=C['quiet'], lw=0.9); a.set_yticks(y); a.set_yticklabels([]); a.invert_yaxis(); a.grid(axis='y', visible=False)
    a.axhline(7.5, color='#c9c8c3', lw=0.8); a.set_xlabel('EV delay difference (s)'); a.set_title('(b) Nominal vs. deployable baselines, EV delay', loc='left')
    a.legend(frameon=False, loc='lower left', fontsize=7)
    fig.text(0.02, -0.12, 'Test scenes, 332–336 replays per condition. (b) mean and 95% scene-bootstrap interval; no interval lies above zero.', fontsize=7.2, color=C['quiet'])
    fig.tight_layout(); save(fig, 'fig7_nominal')


# ------------------------------------------------------------------------------------------- Fig. 8 mechanism
def fig_mech():
    groups = [('all candidate cars', 'All candidates'), ('would yield on its own (complies, no panic)', 'Would yield alone'),
              ('panics when yielding by itself', 'Would panic'), ('does not comply on its own', 'Would not comply'),
              ('ignores commands', 'Ignores commands'), ('obeys commands', 'Obeys commands')]
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.7), sharey=True)
    for ai, (k, title) in enumerate([('D0', 'D0 default'), ('D', 'D extreme'), ('O40', 'O40, 40% ignore')]):
        a = axs[ai]; g = Dt.MECH[k]['groups']; gs = [(lab, g[key]) for key, lab in groups if key in g]
        x = np.arange(len(gs))
        a.bar(x - 0.19, [v[0] for _, v in gs], 0.36, color=C['oracle'], label='oracle')
        a.bar(x + 0.19, [v[1] for _, v in gs], 0.36, color=C['reactive'], label='broadcast rule')
        for xi, (_, v) in zip(x, gs): a.text(xi - 0.19, v[0] + 1.5, f'{v[0]:.0f}', ha='center', fontsize=6.6, color=C['ink'])
        a.set_xticks(x); a.set_xticklabels([lab for lab, _ in gs], rotation=35, ha='right'); a.grid(axis='x', visible=False); a.set_ylim(0, 108)
        dO, dR = Dt.MECH[k]['dist_o'][1], Dt.MECH[k]['dist_r'][1]
        a.set_title(f'({"abc"[ai]}) {title}', loc='left')
        a.text(0.02, 0.97, f'median distance when commanded:\noracle {dO} m, broadcast {dR} m', transform=a.transAxes, fontsize=6.8, va='top', color=C['quiet'])
    axs[0].set_ylabel('Candidate vehicles commanded (%)'); fig.legend(handles=[Patch(fc=C['oracle'], label='oracle'), Patch(fc=C['reactive'], label='broadcast rule')], frameon=False, loc='upper right', ncol=2, fontsize=7.5, bbox_to_anchor=(1.0, 1.06))
    fig.text(0.02, -0.12, f'ρ = 1.0, test scenes; each candidate vehicle counted once (D0: {Dt.MECH["D0"]["cars"]} vehicles, D: {Dt.MECH["D"]["cars"]}, O40: {Dt.MECH["O40"]["cars"]}). Broadcast = what the broadcast rule would do in the states the oracle visited.', fontsize=7.0, color=C['quiet'])
    fig.tight_layout(); save(fig, 'fig8_mechanism')


# ------------------------------------------------------------------------------------------- Fig. 9 dataset
def fig_dataset():
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.3), gridspec_kw=dict(width_ratios=[1.2, 1]))
    a = axs[0]; x = np.arange(3); rl = ['0.25', '0.5', '1.0']
    tr, va = Dt.DS['train']['by_rho'], Dt.DS['val']['by_rho']
    a.bar(x - 0.18, tr, 0.34, color=C['oracle'], label=f'training ({Dt.DS["train"]["decisions"]:,})')
    a.bar(x + 0.18, va, 0.34, color=C['nominal'], label=f'development ({Dt.DS["val"]["decisions"]:,})')
    for xi, t, v in zip(x, tr, va): a.text(xi - 0.18, t + 60, f'{t:,}', ha='center', fontsize=7); a.text(xi + 0.18, v + 60, f'{v:,}', ha='center', fontsize=7)
    a.set_xticks(x); a.set_xticklabels([f'ρ = {r}' for r in rl]); a.set_ylabel('Decision points'); a.grid(axis='x', visible=False)
    a.legend(frameon=False, loc='upper left'); a.set_title('(a) Decision points by penetration', loc='left'); a.set_ylim(0, 5200)
    a = axs[1]; labs = ['EV progress\nspread (m)', 'Metres lost\nspread (m)']; x = np.arange(2)
    t = [Dt.DS['train']['ev_spread'], Dt.DS['train']['lost_spread']]; v = [Dt.DS['val']['ev_spread'], Dt.DS['val']['lost_spread']]
    a.bar(x - 0.18, t, 0.34, color=C['oracle']); a.bar(x + 0.18, v, 0.34, color=C['nominal'])
    for xi, ti, vi in zip(x, t, v): a.text(xi - 0.18, ti + 0.2, f'{ti:.2f}', ha='center', fontsize=7); a.text(xi + 0.18, vi + 0.2, f'{vi:.2f}', ha='center', fontsize=7)
    a.set_xticks(x); a.set_xticklabels(labs); a.grid(axis='x', visible=False); a.set_title('(b) Best-to-worst command, 6 s', loc='left'); a.set_ylim(0, 15.5)
    fig.tight_layout(); save(fig, 'fig9_dataset')


if __name__ == '__main__':
    for f in (fig_framework, fig_branching, fig_dev, fig_rho, fig_all, fig_forest, fig_nominal, fig_mech, fig_dataset): f()
    print('ok')
