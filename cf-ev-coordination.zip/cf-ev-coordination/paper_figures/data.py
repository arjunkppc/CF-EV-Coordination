"""
Single source of every number in the manuscript. All values are parsed from the raw cluster outputs in src_*.txt
(copied verbatim from the user's runs). Nothing here is typed by hand except the parsing rules.
"""
import re, os
HERE = os.path.dirname(os.path.abspath(__file__))
R = lambda f: open(os.path.join(HERE, f), encoding='utf-8').read()
NUM = r'[+-]?\d+(?:\.\d+)?'
MODELS = ['D0', 'A', 'B', 'C', 'D', 'L', 'O20', 'O40']
RHOS = ['1.0', '0.5']


def ci(s):
    m = re.match(rf'\s*({NUM})\s*\[\s*({NUM})\s*,\s*({NUM})\s*\]', s)
    return tuple(float(x) for x in m.groups())


# ---------------------------------------------------------------- main 16-condition table (paperA_table_v2)
TAB = {}
for line in R('src_tableA_v2_mech.txt').splitlines():
    m = re.match(r'^(D0|A|B|C|D|L|O20|O40)\s+(1\.0|0\.5)\s+(\d+)\s+(\d+)\s+(\S+)\s+(\S+)\s*\|(.*)$', line)
    if not m or 'nominal recovers' not in line: continue
    mod, rho, n, mm, rd, rl, rest = m.groups()
    cells = [c.strip() for c in rest.split('|')]
    def dl(c):
        mm_ = re.match(rf'({NUM})(\*?)\s*/\s*({NUM})%(\*?)', c)
        return dict(d=float(mm_.group(1)), d_sig=mm_.group(2) == '*', p=float(mm_.group(3)), p_sig=mm_.group(4) == '*')
    row = dict(n=int(n), mm=int(mm), r_delay=float(rd), r_lost=float(rl),
               oracle=dl(cells[0]), nominal=dl(cells[1]), jit=dl(cells[2]), pace=dl(cells[3]), passed=cells[4] == 'YES')
    oj = [x.strip() for x in cells[5].split('/')]; op = [x.strip() for x in cells[6].split('/')]
    row['o_minus_jit'] = dict(d=ci(oj[0]), l=ci(oj[1])); row['o_minus_pace'] = dict(d=ci(op[0]), l=ci(op[1]))
    rec = re.search(r'delay\s+(\d+)%,\s*lost\s+(\d+)%', cells[7])
    row['rec_delay'], row['rec_lost'] = int(rec.group(1)), int(rec.group(2))
    TAB[(mod, rho)] = row
assert len(TAB) == 16, len(TAB)

# ---------------------------------------------------------------- robust table: CIs for oracle and PACE vs reactive
ROB = {}
for line in R('src_robust.txt').splitlines():
    m = re.match(rf'^(\S+)\s+(\S+)\s+(\d+)\s+(\d+)\s*\|\s*(\S+)\s+(\S+)\s*\|(.*)\|(.*)$', line)
    mod, rho, n, mm, rd, rl, a, b = m.groups()
    def two(s):
        s = s.replace('YES', '')
        x = re.findall(rf'{NUM}\s*\[\s*{NUM}\s*,\s*{NUM}\s*\]', s)
        return ci(x[0]), ci(x[1])
    od, ol = two(a); pdd, pl = two(b)
    ROB[(mod, rho)] = dict(n=int(n), r_delay=float(rd), r_lost=float(rl), o_d=od, o_l=ol, p_d=pdd, p_l=pl)

# ---------------------------------------------------------------- nominal pairwise CIs
NOMP = {}
for line in R('src_nominal_pairs.txt').splitlines():
    m = re.match(r'^(\S+)\s+(\S+)\s+(\d+)\s*\|(.*)$', line)
    mod, rho, n, rest = m.groups()
    cells = [c for c in rest.split('|') if c.strip()]
    out = {}
    for name, c in zip(['reactive', 'jit', 'pace', 'oracle'], cells):
        a, b = c.split('/')
        out[name] = dict(d=ci(a), l=ci(b))
    NOMP[(mod, rho)] = dict(n=int(n), **out)
assert len(NOMP) == 16

# ---------------------------------------------------------------- default model gate + PACE at three rho
GATE, PACE0 = {}, {}
for line in R('src_gate_D0.txt').splitlines():
    if line.startswith('rho') and 'oracle' in line:
        rho = line.split()[1]
        d = ci(line.split('oracle delay')[1]); l = ci(line.split('lost')[1]); c = ci(line.split('cmds')[1])
        pct = float(re.search(r'\((' + NUM + r')%\)', line).group(1))
        GATE[rho] = dict(d=d, l=l, pct=pct, cmd=c)
    elif line.startswith('pace'):
        rho = line.split()[2]
        PACE0[rho] = dict(d=ci(line.split('delay')[1]), dist=ci(line.split('disturbed')[1]),
                          conf=ci(line.split('civ_conflicts')[1]), l=ci(line.split('lost')[1]))
HEAD = dict(n=332, scenes=130, react_cmd_share=97.6)

# ---------------------------------------------------------------- development check (25 replays, rho 0.5)
DEV = {}
txt = R('src_dev.txt')
for H in ('8', '15'):
    block = txt.split(f"'oracle_l0.25_H{H}_nocoord'")[1] if False else None
for line in txt.splitlines():
    m = re.match(r'^(nocoord|reactive|oracle_\S+|pace_cv|pace_eva)\s+(' + NUM + r')\s+(' + NUM + r')\s+(' + NUM + r')\s+(' + NUM + r')\s+(' + NUM + r')\s+(' + NUM + r')\s+(' + NUM + r')\s+(' + NUM + r')\s+(' + NUM + r')\s+(' + NUM + r')\s*$', line)
    if m:
        k = m.group(1); vals = [float(x) for x in m.groups()[1:]]
        DEV[k] = dict(zip(['ev_delay', 'ev_speed', 'ev_stops', 'ev_hb', 'commands', 'disturbed', 'civ_conflicts', 'civ_near', 'lost_m', 'coll_sim'], vals))
DEV_DIFF = {}
for line in txt.splitlines():
    m = re.match(r'^(oracle_\S+|pace_eva)\s+ev_delay\s+(.*?)\s+disturbed\s+(.*?)\s+civ_conflicts\s+(.*?)\s+lost_m\s+(.*)$', line)
    if m and m.group(1) not in DEV_DIFF:      # first occurrence = "policy - reactive" block
        DEV_DIFF[m.group(1)] = dict(d=ci(m.group(2)), dist=ci(m.group(3)), conf=ci(m.group(4)), l=ci(m.group(5)))
DEV_N = dict(replays=25, scenes=13, react_cmd_share=72.0)

# ---------------------------------------------------------------- JIT trigger selection on development scenes
JIT = {}
for line in R('src_jit_tableA.txt').splitlines():
    m = re.match(r'^(jit\d+|reactive)\s+J\s+(' + NUM + r')\s+delay\s+(' + NUM + r')\s+lost\s+(' + NUM + r')\s+cmds\s+(' + NUM + r')', line)
    if m: JIT[m.group(1)] = dict(J=float(m.group(2)), delay=float(m.group(3)), lost=float(m.group(4)), cmds=float(m.group(5)))
JIT_N = int(re.search(r'(\d+) development replays', R('src_jit_tableA.txt')).group(1))

# ---------------------------------------------------------------- mechanism (per car)
MECH = {}
cur = None
for line in R('src_mech_v2.txt').splitlines():
    m = re.match(r'=== mech_(\S+)_dec\.jsonl: (\d+) candidate cars in (\d+) replays', line)
    if m: cur = m.group(1); MECH[cur] = dict(cars=int(m.group(2)), replays=int(m.group(3)), groups={}); continue
    m = re.match(r'^(.*?)\s+(' + NUM + r')%\s+(' + NUM + r')%\s+(\d+)\s*$', line)
    if m: MECH[cur]['groups'][m.group(1).strip()] = (float(m.group(2)), float(m.group(3)), int(m.group(4))); continue
    m = re.search(r'oracle (\d+) / (\d+) / (\d+) m \| reactive rule (\d+) / (\d+) / (\d+) m', line)
    if m: MECH[cur]['dist_o'] = tuple(map(int, m.groups()[:3])); MECH[cur]['dist_r'] = tuple(map(int, m.groups()[3:])); continue
    m = re.search(r'both command (\d+) \| only reactive rule (\d+) \| only oracle (\d+) \| neither (\d+)', line)
    if m: MECH[cur]['agree'] = tuple(map(int, m.groups()))

# ---------------------------------------------------------------- dataset + timing
DS = {}
for line in R('src_dataset.txt').splitlines():
    if line.startswith(('train', 'val')):
        k = line.split(':')[0]
        g = lambda key: float(re.search(key + r'\s+(' + NUM + r')', line).group(1))
        rh = re.search(r'by_rho 0\.25:(\d+) 0\.5:(\d+) 1:(\d+)', line).groups()
        DS[k] = dict(decisions=int(g('decisions')), replays=int(g('replays')), branches=g('branches_mean'),
                     by_rho=tuple(map(int, rh)), ev_spread=g('ev_progress_spread_m'), lost_spread=g('lost_spread_m'),
                     share_change=g('share_change'))
TIME = dict(re.findall(r'(nocoord|reactive|oracle_l0\.25|oracle_l0|oracle_l1) (' + NUM + ')', R('src_dataset.txt')))


# ---------------------------------------------------------------- consistency checks between independent outputs
def checks():
    problems = []
    for (mod, rho), r in TAB.items():
        if r['mm'] != 0: problems.append(f'{mod} {rho}: mismatch count {r["mm"]}')
        if not r['passed']: problems.append(f'{mod} {rho}: gate not passed')
        if (mod, rho) in ROB:
            b = ROB[(mod, rho)]
            for k1, k2 in (('r_delay', 'r_delay'), ('r_lost', 'r_lost')):
                if abs(r[k1] - b[k2]) > 1e-9: problems.append(f'{mod} {rho} {k1}: {r[k1]} vs {b[k2]}')
            if round(b['o_d'][0], 2) != r['oracle']['d']: problems.append(f'{mod} {rho} oracle delay {b["o_d"][0]} vs {r["oracle"]["d"]}')
            if round(b['p_d'][0], 2) != r['pace']['d'] and not (abs(b['p_d'][0]) < 0.005 and r['pace']['d'] == 0): problems.append(f'{mod} {rho} pace delay {b["p_d"][0]} vs {r["pace"]["d"]}')
            if (b['o_d'][2] < 0 or b['o_d'][1] > 0) != r['oracle']['d_sig']: problems.append(f'{mod} {rho} oracle delay sig')
            if (b['o_l'][2] < 0 or b['o_l'][1] > 0) != r['oracle']['p_sig']: problems.append(f'{mod} {rho} oracle lost sig')
            if (b['p_d'][2] < 0 or b['p_d'][1] > 0) != r['pace']['d_sig']: problems.append(f'{mod} {rho} pace delay sig')
            if (b['p_l'][2] < 0 or b['p_l'][1] > 0) != r['pace']['p_sig']: problems.append(f'{mod} {rho} pace lost sig')
            for nm, cil in (('oracle', b['o_l']), ('pace', b['p_l'])):
                if abs(100 * cil[0] / r['r_lost'] - r[nm]['p']) > 0.6: problems.append(f'{mod} {rho} {nm} lost % {100*cil[0]/r["r_lost"]:.2f} vs {r[nm]["p"]}')
        n = NOMP[(mod, rho)]
        if n['n'] != r['n']: problems.append(f'{mod} {rho} n')
        if n['reactive']['d'][0] != r['nominal']['d']: problems.append(f'{mod} {rho} nominal delay {n["reactive"]["d"][0]} vs {r["nominal"]["d"]}')
        if abs(100 * n['reactive']['l'][0] / r['r_lost'] - r['nominal']['p']) > 0.6: problems.append(f'{mod} {rho} nominal lost %')
        sig = lambda c: c[2] < 0 or c[1] > 0
        if sig(n['reactive']['d']) != r['nominal']['d_sig']: problems.append(f'{mod} {rho} nominal delay sig')
        if sig(n['reactive']['l']) != r['nominal']['p_sig']: problems.append(f'{mod} {rho} nominal lost sig')
        # oracle - reactive recomputed through the nominal path must agree within rounding
        od = n['reactive']['d'][0] - n['oracle']['d'][0]
        if abs(od - r['oracle']['d']) > 0.021: problems.append(f'{mod} {rho} oracle delay via nominal {od:.3f} vs {r["oracle"]["d"]}')
        # jit - reactive via two paths
        jd = r['oracle']['d'] - r['o_minus_jit']['d'][0]
        if abs(jd - r['jit']['d']) > 0.021: problems.append(f'{mod} {rho} jit delay path {jd:.3f} vs {r["jit"]["d"]}')
    for rho in ('0.5', '1.0'):
        g = GATE[rho]; b = ROB[('D0', rho)]
        if abs(g['d'][0] - b['o_d'][0]) > 1e-9 or abs(round(g['l'][0], 1) - b['o_l'][0]) > 1e-9: problems.append(f'gate vs robust D0 {rho}')
        p = PACE0[rho]
        if abs(p['d'][0] - b['p_d'][0]) > 1e-9 or abs(round(p['l'][0], 1) - b['p_l'][0]) > 1e-9: problems.append(f'pace0 vs robust D0 {rho}')
    for k, m in MECH.items():
        a = m['agree']
        if sum(a) != m['cars']: problems.append(f'mech {k} agree sum {sum(a)} vs {m["cars"]}')
        g = m['groups']
        s3 = sum(g[x][2] for x in ('would yield on its own (complies, no panic)', 'panics when yielding by itself', 'does not comply on its own'))
        if s3 != m['cars']: problems.append(f'mech {k} group sum')
        o = 100 * (a[0] + a[2]) / m['cars']; rr = 100 * (a[0] + a[1]) / m['cars']
        if abs(o - g['all candidate cars'][0]) > 0.06 or abs(rr - g['all candidate cars'][1]) > 0.06: problems.append(f'mech {k} shares')
    for k, d in DS.items():
        if sum(d['by_rho']) != d['decisions']: problems.append(f'dataset {k} by_rho sum')
    return problems


if __name__ == '__main__':
    p = checks()
    print('consistency problems:', p if p else 'none')
    print('rows', len(TAB), 'robust', len(ROB), 'nomp', len(NOMP), 'gate', sorted(GATE), 'dev', sorted(DEV), 'devdiff', sorted(DEV_DIFF))
    print('jit', JIT, JIT_N); print('mech', {k: (v['cars'], v['replays']) for k, v in MECH.items()}); print('ds', DS); print('time', TIME)
