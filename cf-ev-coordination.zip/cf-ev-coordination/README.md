# Counterfactual Evaluation of Connected-Vehicle Coordination for Emergency-Vehicle Corridors

Code for the paper

> Arjun K P. *Counterfactual Evaluation of Connected-Vehicle Coordination for Emergency-Vehicle Corridors on Real
> Traffic: Performance Ceiling, Robustness, and a Deployable Model-Predictive Coordinator.* (under review)

When an emergency vehicle (EV) approaches, a coordinator that can message connected vehicles (CVs) has to decide which
of them to move aside and when. Logged traffic only shows the commands that were actually issued, so the effect of a
different command cannot be measured from it. This repository builds that measurement: reactive replays of real
nuScenes traffic with an injected EV are branched exactly at each decision point, so every alternative command is
evaluated from the same traffic state with the same drivers.

The repository contains

- **exact branching** of a running replay (`cf_fork.py`): a copy continues bit-for-bit like the original;
- the **oracle coordinator** (performance ceiling): tries every candidate command in a copy with the true driver traits;
- the **nominal coordinator** (deployable): the same rollout, but drivers that have not yet reacted are re-drawn from
  the default population model and commands are assumed to be obeyed;
- baselines: reactive V2X broadcast, just-in-time warning (JIT), and the forecast-based PACE-EVA coordinator;
- eight driver-response models (D0, A, B, C, D, L, O20, O40), including drivers who ignore commands;
- the decision rules written before each test run (`prereg/`), the analysis scripts that apply them, and the
  generator of the paired **counterfactual dataset**;
- the scripts that redraw every figure of the paper from the recorded outputs (`paper_figures/`).

## Main results (held-out nuScenes val scenes, default driver model D0, 100% CV penetration, 332 replays)

| Coordinator | EV delay (s) | Δ vs. broadcast | Civilian metres lost | Δ vs. broadcast |
|---|---|---|---|---|
| Reactive broadcast | 2.34 | — | 103.6 | — |
| JIT-12 | 2.65 | +0.31* | 94.8 | −8%* |
| PACE-EVA | 2.53 | +0.19 | 95.3 | −8%* |
| Nominal (proposed, deployable) | 2.08 | −0.26 | 96.0 | −7%* |
| Oracle (ceiling) | 1.95 | −0.39* | 83.4 | −19%* |

\* 95% scene-level bootstrap interval excludes zero. Absolute means are the broadcast mean plus the paired difference.

Across all 16 test conditions (8 driver models × 50% / 100% penetration) the oracle was less disruptive than the
broadcast in all 16 and clearly faster in 14; the nominal coordinator was never clearly slower than any baseline, was
less disruptive than the broadcast in all 16, and recovered 25–50% of the oracle's reduction in disruption. The
counterfactual dataset has 9,592 decision points (8,738 training, 854 development).

## Repository layout

```
ns_ev/            NS-EV reactive replay of nuScenes and the PACE baseline coordinators (from the NS-EV study)
coordination/     branching, oracle / nominal / JIT coordinators, obedience model, dataset generator
analysis/         paired comparisons, scene bootstrap, decision rules, tables, mechanism, full metric export
slurm/            one job script per step, in run order (00 ... 08)
prereg/           decision rules, each dated and written before the test runs it governs
paper_figures/    recorded outputs of every run used in the paper + scripts that redraw Figs. 1-9
tools/            add_nsev_files.sh (completes ns_ev/), check_repo.py (pre-publication check)
runs/             all outputs are written here (ignored by git)
```

## Installation

```bash
git clone https://github.com/<user>/cf-ev-coordination.git
cd cf-ev-coordination
pip install -r requirements.txt
cp config.example.sh config.sh      # then set DATAROOT, PY and, if needed, WORKERS
```

**Data.** Download nuScenes v1.0-trainval from https://www.nuscenes.org/ (registration required; the dataset has
its own licence, CC BY-NC-SA 4.0). Only the annotation tables are read; camera and lidar data are not needed. The
official splits are used: the 150 `val` scenes are the test set, every tenth `train` scene (70) is the development
set, and the other 630 `train` scenes are used only to build the counterfactual dataset.

**Forecasters.** PACE-EVA needs the trained EVA-Net and Social-Attention models of the NS-EV study
(`nsevdr_s0_model_pace_K6.pkl`, `nsevdr_s0_model_social_K6.pkl`). Place them in `runs/`, or point `EVA` and `SOC`
in `config.sh` to them. All other coordinators run without them.

## Reproducing the paper

Submit from the repository root, in this order. Every job is resumable: resubmitting skips finished replays.
Times are estimates for 8 cores: the oracle needed about 1.4 s per 20-s replay at λ = 0.25 (1.3–2.1 s across
λ ∈ {0, 0.25, 1}) and a replay without coordination about 0.3 s, measured on development scenes. The NS-EV baseline
runs (steps 00, 01 and the background runs in 04, 05) were not timed in this study, so only their wall-time limits
are given.

| Step | Script | What it does | Expected time (8 cores) |
|---|---|---|---|
| 0a | `sbatch slurm/00_nsev_baselines_dev.slurm` | PACE threshold sweep on dev scenes; write the chosen lead time to `runs/chosen_tl.txt` (15) | not timed here (limit 12 h) |
| 0b | `sbatch slurm/01_nsev_baselines_test.slurm` | no coordination, broadcast, PACE on test, ρ = 0.25 / 0.5 / 1.0 | not timed here (limit 24 h) |
| 1 | `sbatch slurm/02_oracle_dev.slurm` | oracle check on 15 dev scenes, H = 8 and 15 s | about 10 min |
| 2 | `sbatch slurm/03_oracle_test.slurm` | oracle on test, three penetration rates, two horizons | about 0.5–1 h |
| 3 | `sbatch slurm/04_stress_models.slurm` | driver models A, B, C, D, L; robustness table | about 1 h for the oracle part, plus the NS-EV runs (limit 24 h) |
| 4 | `sbatch slurm/05_jit_and_obedience.slurm` | JIT tuning and test; obedience O20 / O40; main table | about 1–3 h (limit 24 h) |
| 5 | `sbatch slurm/06_nominal_and_mechanism.slurm` | nominal coordinator in all 16 conditions; oracle decision logs with traits | about 2–3 h (limit 24 h) |
| 6 | `sbatch slurm/07_counterfactual_dataset.slurm` | paired counterfactual dataset from training and dev scenes | about 0.5–2 h (limit 12 h) |
| 7 | `bash slurm/08_analysis.sh` | pairwise comparisons, mechanism, all secondary metrics (`all_metrics_test.csv`) | about 5 min, no simulation |

Check after step 2: every summary must report `nocoord/reactive mismatches ... 0`. A non-zero value means the
replays do not reproduce the NS-EV runs and the paired comparison is not valid.

**Figures only.** The outputs used in the paper are stored in `paper_figures/src_*.txt`, so the figures can be
redrawn without any simulation:

```bash
cd paper_figures && python data.py && python figs.py     # writes paper_figures/figs/fig1 ... fig9 (.png, .pdf)
```

## Counterfactual dataset format

One record per decision point (every 0.5 s with at least one candidate), up to 24 nearby vehicles plus the EV:
`hist` (4 frames, 2.0–0.5 s before the decision), `now`, `mask`, `cand`, and for each of up to 8 alternative commands
`act`, `fut` (13 frames: the decision step and +0.5 … +6.0 s; use frames 1–12 as the future) and `out` (EV progress, metres lost, commands, conflicts, near misses, collisions,
hard brakes, vehicles disturbed). `trait` holds the hidden driver traits for analysis only; they must not be used as
model inputs. See the docstring of `coordination/cf_generate.py` for all fields.

## Before publishing this repository

`ns_ev/` still needs four modules from the NS-EV code (`features.py`, `sim.py`, `model.py`, `summarize_cl.py`):

```bash
bash tools/add_nsev_files.sh /path/to/your/nsev      # copies them and runs the check below
python3 tools/check_repo.py                          # must print "repository check passed"
```

## Citation

```bibtex
@unpublished{kp_cfev,
  author = {K P, Arjun},
  title  = {Counterfactual Evaluation of Connected-Vehicle Coordination for Emergency-Vehicle Corridors on Real
            Traffic: Performance Ceiling, Robustness, and a Deployable Model-Predictive Coordinator},
  note   = {Under review},
  year   = {2026}
}
```

## Licence

Code: MIT (see `LICENSE`). nuScenes data and the nuScenes devkit are under their own licences.
