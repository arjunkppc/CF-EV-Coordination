#!/bin/bash
# Step 7 (no simulation, a few minutes on a login node): pairwise tables, mechanism and full secondary metrics.
cd "$(dirname "$0")/.."; source ./config.sh; cd "$RUNS"; A="$REPO/analysis"
J=jit$(cat chosen_jit.txt)
SPECS=""
for RHO in 1.0 0.5; do
  SPECS="$SPECS D0:$RHO:or_test_rho${RHO}_H15.jsonl:cl_test_rho${RHO}.jsonl"
  for M in A B C D L O20 O40; do SPECS="$SPECS $M:$RHO:st_${M}_rho${RHO}_or.jsonl:st_${M}_rho${RHO}_cl.jsonl"; done
done
$PY "$A/compare_nominal.py" --jit $J $SPECS > nominal_pairs.txt
$PY "$A/mechanism_v2.py" mech_D0_dec.jsonl mech_D_dec.jsonl mech_O40_dec.jsonl > mechanism_v2.txt
$PY "$A/export_all_metrics.py" --jit $J $SPECS > all_metrics_test.txt     # also writes all_metrics_test.csv
cat nominal_pairs.txt mechanism_v2.txt; tail -3 all_metrics_test.txt
