"""
cf-ev-coordination / robust_table.py - Step 6 summary: is the oracle's headroom robust across driver-response models?

  python robust_table.py TAG:RHO:oracle.jsonl:closedloop.jsonl  [more ...]  > robust_table.txt

For every (driver model, rho): replays, reproduction check, reactive means, and the paired differences
(scene-bootstrap 95% CI) of the primary oracle and of PACE-EVA against reactive, plus the pre-registered pass/fail.
"""
import sys, numpy as np
from compare_oracle import load, boot

PRIM = 'oracle_l0.25_H15_nocoord'


def diff(M, keys, sc, p, m):
    d = np.array([M[k][p][m] - M[k]['reactive'][m] for k in keys], float); return boot(d, sc)


rows = []
print(f'primary oracle: {PRIM}; differences are policy - reactive, mean [95% CI]\n')
hdr = '%-9s %4s %5s %3s | %7s %7s | %-27s %-30s %4s | %-27s %-30s' % (
    'model', 'rho', 'n', 'mm', 'delay', 'lost', 'oracle: EV delay (s)', 'oracle: lost m (%)', 'pass',
    'PACE-EVA: EV delay (s)', 'PACE-EVA: lost m (%)')
print(hdr); print('-' * len(hdr))
for spec in sys.argv[1:]:
    tag, rho, fo, fc = spec.split(':', 3)
    O, C = load(fo), load(fc)
    both = [k for k in O if k in C]
    mm = sum(1 for k in both for p in ('nocoord', 'reactive')
             if p in O[k] and p in C[k] and abs(O[k][p]['ev_progress'] - C[k][p]['ev_progress']) > 1e-6)
    M = {k: dict(C[k], **{p: r for p, r in O[k].items() if p.startswith('oracle')}) for k in both}
    keys = [k for k in M if PRIM in M[k] and 'pace_eva' in M[k] and 'reactive' in M[k]]
    if not keys: print(f'{tag:9s} {rho:>4s}  no complete replays'); continue
    sc = [k[0] for k in keys]
    rd = np.mean([M[k]['reactive']['ev_delay'] for k in keys]); rl = np.mean([M[k]['reactive']['lost_m'] for k in keys])
    od, ol, pd, pl = (diff(M, keys, sc, p, m) for p in (PRIM, 'pace_eva') for m in ('ev_delay', 'lost_m'))
    ok = od[2] <= 0.10 and ol[2] < 0
    f = lambda x: f'{x[0]:+.3f} [{x[1]:+.3f},{x[2]:+.3f}]'
    g = lambda x: f'{x[0]:+.1f} [{x[1]:+.1f},{x[2]:+.1f}] ({100 * x[0] / max(rl, 1e-9):+.0f}%)'
    print('%-9s %4s %5d %3d | %7.2f %7.1f | %-27s %-30s %4s | %-27s %-30s' % (tag, rho, len(keys), mm, rd, rl, f(od), g(ol),
          'YES' if ok else 'no', f(pd), g(pl)))
    rows.append((tag, rho, ok, mm))
print('\nmm = nocoord/reactive mismatches between the oracle run and the closed-loop run (must be 0)')
r1 = [r for r in rows if r[1] in ('1.0', '1')]
if r1:
    n_ok = sum(r[2] for r in r1)
    print(f'PRE-REGISTERED (PREREG_step6.txt): rho = 1.0 passes under {n_ok}/{len(r1)} driver models -> ' +
          ('ROBUST' if n_ok == len(r1) else 'PARTLY ROBUST' if 2 * n_ok >= len(r1) else 'NOT ROBUST'))
