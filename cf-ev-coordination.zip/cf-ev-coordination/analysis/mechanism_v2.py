"""
cf-ev-coordination / mechanism_v2.py - WHY does the oracle win? Per-CAR analysis of the oracle's decision logs.

  python mechanism_v2.py mech_D0_dec.jsonl mech_D_dec.jsonl mech_O40_dec.jsonl > mechanism_v2.txt

Unit = one connected vehicle that became a command candidate in one replay (counted once, unlike mechanism.py,
which counted every 0.5-s moment and so over-weighted cars the oracle waits on).
  oracle commanded : the oracle commanded this car at some point; 'gap' = distance to the EV when it did
  reactive rule    : the reactive rule (gap < 150 m and target free now) would have commanded it at some logged
                     moment; 'gap' = distance at the first such moment.
Caveat: both are read off the ORACLE's trajectory; the reactive rule's choices are what it would do in those
states, not a record of the separate reactive run. Hidden traits are fixed per driver (perception range and
reaction time vary, the three flags below do not).
"""
import json, sys, collections, numpy as np

for f in sys.argv[1:]:
    cars = collections.OrderedDict()
    for l in open(f):
        d = json.loads(l)
        if 'ctr' not in d: continue
        key0 = tuple(d['tag'][:2])
        for j, g, c in zip(d['cands'], d['gaps'], d['ctr']):
            k = key0 + (j,)
            if k not in cars: cars[k] = dict(trait=c, first_gap=g, o=None, r=None, aware=False)
            car = cars[k]; car['aware'] |= c['aware']
            if car['r'] is None and g < 150 and c['free_now']: car['r'] = g
            if car['o'] is None and j in d['chosen']: car['o'] = g
    C = list(cars.values()); n = len(C)
    if not n: print(f, 'no logged candidates'); continue
    pct = lambda S, w: 100 * np.mean([c[w] is not None for c in S]) if S else float('nan')
    print(f'\n=== {f}: {n} candidate cars in {len({k[:2] for k in cars})} replays')
    print('%-46s %9s %9s %6s' % ('cars', 'oracle', 'reactive', 'n'))
    groups = [('all candidate cars', lambda c: True),
              ('would yield on its own (complies, no panic)', lambda c: c['trait']['comply'] and not c['trait']['freeze']),
              ('panics when yielding by itself', lambda c: c['trait']['freeze']),
              ('does not comply on its own', lambda c: not c['trait']['comply']),
              ('became aware of the EV while a candidate', lambda c: c['aware'])]
    if any(c['trait'].get('ignores') for c in C):
        groups += [('ignores commands', lambda c: c['trait'].get('ignores')),
                   ('obeys commands', lambda c: not c['trait'].get('ignores'))]
    for name, fn in groups:
        S = [c for c in C if fn(c)]
        print('%-46s %8.1f%% %8.1f%% %6d' % (name, pct(S, 'o'), pct(S, 'r'), len(S)))
    og = np.array([c['o'] for c in C if c['o'] is not None]); rg = np.array([c['r'] for c in C if c['r'] is not None])
    q = lambda x: '%.0f / %.0f / %.0f m' % tuple(np.percentile(x, [25, 50, 75])) if len(x) else 'n/a'
    print('distance to the EV when commanded (25th / median / 75th pct): oracle %s | reactive rule %s' % (q(og), q(rg)))
    both = sum(c['o'] is not None and c['r'] is not None for c in C); onlyr = sum(c['o'] is None and c['r'] is not None for c in C)
    onlyo = sum(c['o'] is not None and c['r'] is None for c in C); none = n - both - onlyr - onlyo
    print(f'cars: both command {both} | only reactive rule {onlyr} | only oracle {onlyo} | neither {none}')
