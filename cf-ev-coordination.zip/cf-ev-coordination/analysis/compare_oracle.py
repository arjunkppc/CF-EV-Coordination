"""
cf-ev-coordination / compare_oracle.py - Step 4: read the oracle results against the NS-EV study's policies and apply the decision gate.

  python compare_oracle.py or_test_rho0.5.jsonl runs/cl_test_rho0.5.jsonl > or_summary_rho0.5.txt

Checks first that nocoord/reactive reproduce the NS-EV study exactly (otherwise the pairing is invalid), then reports
per-policy means and paired differences (scene-level bootstrap, 95% CI) on the replays every policy completed.
"""
import json, sys, os, collections
import numpy as np

MET = ['ev_delay', 'ev_speed', 'ev_stops', 'ev_hb', 'commands', 'disturbed', 'civ_conflicts', 'civ_near', 'lost_m', 'coll_sim']


def load(f):
    R = collections.defaultdict(dict)
    for l in open(os.path.expanduser(f)):
        r = json.loads(l); R[(r['scene'], r['inj'])][r['policy']] = r
    return R


def boot(diff, scenes, B=2000, seed=0):
    us = sorted(set(scenes)); idx = {s: np.where(np.array(scenes) == s)[0] for s in us}
    rng = np.random.default_rng(seed); out = []
    for _ in range(B):
        pick = rng.choice(len(us), len(us)); ii = np.concatenate([idx[us[p]] for p in pick])
        out.append(diff[ii].mean())
    return float(diff.mean()), float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))


if __name__ == '__main__':
    O, P2 = load(sys.argv[1]), load(sys.argv[2])
    # 1. reproduction check
    both = [k for k in O if k in P2]; bad = 0
    for k in both:
        for p in ('nocoord', 'reactive'):
            if p in O[k] and p in P2[k] and abs(O[k][p]['ev_progress'] - P2[k][p]['ev_progress']) > 1e-6: bad += 1
    print(f'replays in oracle file {len(O)}, in NS-EV file {len(P2)}, shared {len(both)}; '
          f'nocoord/reactive mismatches vs the NS-EV study: {bad}')
    if bad: print('WARNING: replays do not reproduce the NS-EV study - code or settings differ; paired comparison is NOT valid.\n')
    # 2. merge
    M = {}
    for k in both:
        d = dict(P2[k]); d.update({p: r for p, r in O[k].items() if p.startswith('oracle')}); M[k] = d
    pols = sorted({p for d in M.values() for p in d}, key=lambda p: (not p.startswith('nocoord'), not p.startswith('reactive'), p))
    keys = [k for k in M if all(p in M[k] for p in pols)]
    sc = [k[0] for k in keys]
    print(f'policies: {pols}\nreplays with every policy: {len(keys)} ({len(set(sc))} scenes)')
    act = np.mean([M[k]['reactive']['commands'] > 0 for k in keys]) if keys else 0
    print(f'replays where reactive issued >=1 command (coordination possible at all): {100 * act:.1f}%\n')
    # 3. means
    print('%-28s' % 'policy' + ''.join('%11s' % m for m in MET))
    for p in pols:
        print('%-28s' % p + ''.join('%11.3f' % np.mean([M[k][p].get(m, 0) for k in keys]) for m in MET))
    # 4. paired differences
    for ref in ('reactive', 'pace_eva'):
        if ref not in pols: continue
        print(f'\npaired difference (policy - {ref}), mean [95% scene-bootstrap CI]')
        for p in pols:
            if p == ref or not p.startswith('oracle') and p != 'pace_eva': continue
            line = '%-28s' % p
            for m in ('ev_delay', 'disturbed', 'civ_conflicts', 'lost_m'):
                d = np.array([M[k][p][m] - M[k][ref][m] for k in keys], float)
                mu, lo, hi = boot(d, sc); line += f'  {m} {mu:+.3f} [{lo:+.3f},{hi:+.3f}]'
            print(line)
    # 5. speed headroom (descriptive only: the dev check showed it is ~0)
    print('\nspeed headroom: EV-delay gain of each oracle over reactive (s), mean [95% CI]')
    for p in [p for p in pols if p.startswith('oracle')]:
        g = np.array([M[k]['reactive']['ev_delay'] - M[k][p]['ev_delay'] for k in keys], float)
        mu, lo, hi = boot(g, sc); print(f'  {p:28s} {mu:+.3f} [{lo:+.3f},{hi:+.3f}]')
    # 6. PRE-REGISTERED GATE (fixed before the test run, see PREREG.txt)
    prim = sys.argv[3] if len(sys.argv) > 3 else None
    if prim and prim in pols:
        d_del = np.array([M[k][prim]['ev_delay'] - M[k]['reactive']['ev_delay'] for k in keys], float)
        d_lost = np.array([M[k][prim]['lost_m'] - M[k]['reactive']['lost_m'] for k in keys], float)
        d_cmd = np.array([M[k][prim]['commands'] - M[k]['reactive']['commands'] for k in keys], float)
        a1 = boot(d_del, sc); a2 = boot(d_lost, sc); a3 = boot(d_cmd, sc)
        lost_ref = np.mean([M[k]['reactive']['lost_m'] for k in keys])
        ok_speed = a1[2] <= 0.10; ok_lost = a2[2] < 0
        print(f'\nPRE-REGISTERED GATE  primary = {prim} vs reactive')
        print(f'  (a) EV delay difference   {a1[0]:+.3f} s [{a1[1]:+.3f},{a1[2]:+.3f}]   non-inferior (upper CI <= +0.10 s): {ok_speed}')
        print(f'  (b) civilian metres lost  {a2[0]:+.2f} m [{a2[1]:+.2f},{a2[2]:+.2f}]   ({100 * a2[0] / max(lost_ref, 1e-9):+.1f}% of reactive)  lower (upper CI < 0): {ok_lost}')
        print(f'      commands issued       {a3[0]:+.2f} [{a3[1]:+.2f},{a3[2]:+.2f}]   (descriptive)')
        print('  GATE: ' + ('GO - perfect what-if knowledge keeps reactive speed with less disruption' if ok_speed and ok_lost
                            else 'STOP - no disruption headroom at reactive speed'))
    elif prim: print(f'\nprimary policy {prim} not found in file')
