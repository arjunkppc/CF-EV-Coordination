"""
cf-ev-coordination / paperA_table.py - Paper A main table: every driver model x rho, all coordinators against reactive.

  python paperA_table.py --jit jit8 TAG:RHO:oracle.jsonl:closedloop.jsonl [more ...] > paperA_table.txt

Cells: mean difference vs reactive (EV delay s / civilian metres lost %), * = 95% scene-bootstrap CI excludes 0.
Then: pre-registered pass/fail of the primary oracle per row (PREREG.txt / PREREG_step6.txt / PREREG_step6b.txt),
and the oracle's margin over the best non-oracle coordinator (jit and PACE-EVA).
"""
import sys, argparse, numpy as np
from compare_oracle import load, boot

PRIM = 'oracle_l0.25_H15_nocoord'
ap = argparse.ArgumentParser(); ap.add_argument('--jit', required=True); ap.add_argument('--nominal', default='')
ap.add_argument('specs', nargs='+')
a = ap.parse_args()
POLS = [(PRIM, 'oracle')] + ([(a.nominal, 'nominal')] if a.nominal else []) + [(a.jit, a.jit), ('pace_eva', 'PACE-EVA')]


def d(M, keys, sc, p, q, m):
    x = np.array([M[k][p][m] - M[k][q][m] for k in keys], float); return boot(x, sc)


star = lambda x: '*' if x[1] > 0 or x[2] < 0 else ' '
print('cells: policy - reactive, EV delay (s) / civilian metres lost (% of reactive); * = 95% CI excludes 0\n')
hdr = '%-5s %4s %4s %3s %6s %6s |' % ('model', 'rho', 'n', 'mm', 'delay', 'lost') + ''.join(' %-22s|' % n for _, n in POLS) + \
      ' pass | oracle - %s: delay / lost m        | oracle - PACE-EVA: delay / lost m' % a.jit
print(hdr); print('-' * len(hdr))
res = []
for spec in a.specs:
    tag, rho, fo, fc = spec.split(':', 3)
    O, C = load(fo), load(fc)
    both = [k for k in O if k in C]
    mm = sum(1 for k in both for p in ('nocoord', 'reactive')
             if p in O[k] and p in C[k] and abs(O[k][p]['ev_progress'] - C[k][p]['ev_progress']) > 1e-6)
    M = {k: dict(C[k], **{p: r for p, r in O[k].items() if p not in ('nocoord', 'reactive')}) for k in both}
    keys = [k for k in M if all(p in M[k] for p, _ in POLS) and 'reactive' in M[k]]
    if not keys: print(f'{tag:5s} {rho:>4s}  no complete replays'); continue
    sc = [k[0] for k in keys]
    rd = np.mean([M[k]['reactive']['ev_delay'] for k in keys]); rl = np.mean([M[k]['reactive']['lost_m'] for k in keys])
    line = '%-5s %4s %4d %3d %6.2f %6.1f |' % (tag, rho, len(keys), mm, rd, rl)
    for p, _ in POLS:
        dd, dl = d(M, keys, sc, p, 'reactive', 'ev_delay'), d(M, keys, sc, p, 'reactive', 'lost_m')
        line += ' %+6.2f%s / %+4.0f%%%s       |' % (dd[0], star(dd), 100 * dl[0] / max(rl, 1e-9), star(dl))
        if p == PRIM: ok = dd[2] <= 0.10 and dl[2] < 0
    line += ' %4s |' % ('YES' if ok else 'no')
    for q in (a.jit, 'pace_eva'):
        dd, dl = d(M, keys, sc, PRIM, q, 'ev_delay'), d(M, keys, sc, PRIM, q, 'lost_m')
        line += ' %+5.2f [%+5.2f,%+5.2f] / %+5.1f [%+5.1f,%+5.1f] |' % (dd + dl)
    if a.nominal:   # share of the oracle's gain over reactive that the deployable nominal coordinator recovers
        rec = []
        for m in ('ev_delay', 'lost_m'):
            go = np.mean([M[k]['reactive'][m] - M[k][PRIM][m] for k in keys]); gn = np.mean([M[k]['reactive'][m] - M[k][a.nominal][m] for k in keys])
            rec.append(f'{100 * gn / go:5.0f}%' if go > 1e-6 else '   n/a')
        line += ' nominal recovers: delay %s, lost %s |' % tuple(rec)
    print(line); res.append((tag, rho, ok))
print('\nmm = nocoord/reactive mismatches between oracle and closed-loop runs (must be 0)')
for r_ in ('1.0', '0.5'):
    rr = [x for x in res if x[1] == r_]
    if rr: print(f'rho = {r_}: primary oracle passes under {sum(x[2] for x in rr)}/{len(rr)} driver models: ' +
                 ', '.join(f'{x[0]}={"pass" if x[2] else "FAIL"}' for x in rr))
