"""
cf-ev-coordination / select_jit.py - choose the jit trigger time T on DEVELOPMENT scenes only (pre-registered in PREREG_step6b).
Criterion: the same cost the oracle optimises (lam = 0.25), per replay, in metre-equivalents:
  J = 16 * ev_delay + 0.25 * (lost_m + 10 * civ_conflicts + 3 * civ_near + 2 * commands)     (16 m/s = EV desired speed)
Lowest mean J wins; ties -> larger T (fewer early commands).  Writes chosen_jit.txt.
"""
import json, sys, collections, numpy as np
R = collections.defaultdict(dict)
for l in open(sys.argv[1]): r = json.loads(l); R[(r['scene'], r['inj'])][r['policy']] = r
pols = sorted({p for d in R.values() for p in d if p.startswith('jit') or p == 'reactive'})
keys = [k for k in R if all(p in R[k] for p in pols)]
J = lambda r: 16 * r['ev_delay'] + 0.25 * (r['lost_m'] + 10 * r['civ_conflicts'] + 3 * r['civ_near'] + 2 * r['commands'])
print(f'{len(keys)} development replays')
best = None
for p in pols:
    v = np.mean([J(R[k][p]) for k in keys])
    print('%-10s J %8.2f  delay %.3f  lost %.1f  cmds %.2f' % (p, v, np.mean([R[k][p]['ev_delay'] for k in keys]),
          np.mean([R[k][p]['lost_m'] for k in keys]), np.mean([R[k][p]['commands'] for k in keys])))
    if p.startswith('jit') and (best is None or v < best[1] - 1e-9 or (abs(v - best[1]) < 1e-9 and float(p[3:]) > float(best[0][3:]))): best = (p, v)
print('chosen:', best[0]); open('chosen_jit.txt', 'w').write(best[0][3:] + '\n')
