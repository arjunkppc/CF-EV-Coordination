"""
cf-ev-coordination / compare_nominal.py - paired comparison of the deployable nominal coordinator against every other coordinator.

  python compare_nominal.py --jit jit12 TAG:RHO:oracle.jsonl:closedloop.jsonl [more ...] > nominal_pairs.txt

Cells: mean of (nominal - other) [95% scene-bootstrap CI]; negative = nominal is faster / less disruptive.
B = nominal better on that measure (CI below 0), W = worse (CI above 0), blank = no clear difference.
"""
import argparse, numpy as np
from compare_oracle import load, boot

NOM = 'nominal_l0.25_H15_M6'; PRIM = 'oracle_l0.25_H15_nocoord'
ap = argparse.ArgumentParser(); ap.add_argument('--jit', required=True); ap.add_argument('specs', nargs='+')
a = ap.parse_args()
OTHERS = ['reactive', a.jit, 'pace_eva', PRIM]
mark = lambda x: 'B' if x[2] < 0 else ('W' if x[1] > 0 else ' ')
print('nominal - other: EV delay (s) / civilian metres lost (m), mean [95% CI]; B = nominal better, W = worse\n')
hdr = '%-5s %4s %4s |' % ('model', 'rho', 'n') + ''.join(' %-44s|' % ('vs ' + o) for o in OTHERS)
print(hdr); print('-' * len(hdr))
tally = {o: [0, 0, 0, 0] for o in OTHERS}       # delay better, delay worse, lost better, lost worse
for spec in a.specs:
    tag, rho, fo, fc = spec.split(':', 3)
    O, C = load(fo), load(fc)
    M = {k: dict(C[k], **{p: r for p, r in O[k].items() if p not in ('nocoord', 'reactive')}) for k in O if k in C}
    keys = [k for k in M if all(p in M[k] for p in OTHERS + [NOM])]
    if not keys: print(f'{tag:5s} {rho:>4s}  no complete replays'); continue
    sc = [k[0] for k in keys]; line = '%-5s %4s %4d |' % (tag, rho, len(keys))
    for o in OTHERS:
        cell = ''
        for i, m in enumerate(('ev_delay', 'lost_m')):
            x = boot(np.array([M[k][NOM][m] - M[k][o][m] for k in keys], float), sc)
            cell += ('%+5.2f [%+5.2f,%+5.2f]%s' if m == 'ev_delay' else ' / %+5.1f [%+5.1f,%+5.1f]%s') % (x + (mark(x),))
            if x[2] < 0: tally[o][2 * i] += 1
            if x[1] > 0: tally[o][2 * i + 1] += 1
        line += ' %-44s|' % cell
    print(line)
print('\nsummary over conditions (better / worse, by CI):')
for o, t in tally.items():
    print(f'  vs {o:28s} EV delay: better {t[0]:2d}, worse {t[1]:2d} | civilian metres lost: better {t[2]:2d}, worse {t[3]:2d}')
