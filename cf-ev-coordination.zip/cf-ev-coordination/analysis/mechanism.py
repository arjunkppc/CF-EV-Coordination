"""
cf-ev-coordination / mechanism.py - WHY does the oracle win? Uses the oracle's decision logs (with candidate traits).

  python mechanism.py mech_D0_rho1.0_dec.jsonl [mech_O40_rho1.0_dec.jsonl ...]

For every candidate CV at every decision: did the oracle command it, and would the reactive rule have (gap < 150 m
and target free now)? Command rates are broken down by the driver's HIDDEN traits, which only the oracle knows:
would yield on their own (complies, not panic), panics (freezes), ignores commands, plus target occupancy and gap.
"""
import json, sys, collections, numpy as np


def rows(f):
    for l in open(f):
        d = json.loads(l)
        if 'ctr' not in d: continue
        for j, g, c in zip(d['cands'], d['gaps'], d['ctr']):
            yield dict(c, gap=g, oracle=j in d['chosen'], reactive=(g < 150 and c['free_now']))


for f in sys.argv[1:]:
    R = list(rows(f)); n = len(R)
    if not n: print(f, 'no logged candidates'); continue
    rate = lambda S, k='oracle': (100 * np.mean([r[k] for r in S]), len(S)) if S else (float('nan'), 0)
    print(f'\n=== {f}: {n} candidate-decisions')
    o, rr = rate(R), rate(R, 'reactive')
    print(f'commanded overall: oracle {o[0]:.1f}%   reactive rule {rr[0]:.1f}%')
    groups = [('would yield on its own (complies, no panic)', lambda r: r['comply'] and not r['freeze']),
              ('panics when yielding by itself (freezes)', lambda r: r['freeze']),
              ('does not comply on its own', lambda r: not r['comply']),
              ('already aware of the EV', lambda r: r['aware']),
              ('ignores commands', lambda r: r['ignores']),
              ('target occupied now (reactive would not command)', lambda r: not r['free_now'])]
    print('%-52s %8s %8s %7s' % ('candidate group', 'oracle', 'reactive', 'n'))
    for name, fn in groups:
        S = [r for r in R if fn(r)]
        if S: print('%-52s %7.1f%% %7.1f%% %7d' % (name, rate(S)[0], rate(S, 'reactive')[0], len(S)))
    print('by distance to the EV (timing):')
    for lo, hi in [(0, 40), (40, 80), (80, 120), (120, 160), (160, 201)]:
        S = [r for r in R if lo <= r['gap'] < hi]
        if S: print('  %3d-%3d m %40s %7.1f%% %7.1f%% %7d' % (lo, hi, '', rate(S)[0], rate(S, 'reactive')[0], len(S)))
    agree = collections.Counter((r['oracle'], r['reactive']) for r in R)
    print('agreement: both command %d | only reactive %d | only oracle %d | neither %d' %
          (agree[(True, True)], agree[(False, True)], agree[(True, False)], agree[(False, False)]))
