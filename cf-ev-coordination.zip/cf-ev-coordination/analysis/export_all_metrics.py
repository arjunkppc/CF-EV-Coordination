"""
cf-ev-coordination / export_all_metrics.py - full secondary-metric profile on the TEST conditions (for Paper A, Table "test secondary metrics").

  python export_all_metrics.py --jit jit12 TAG:RHO:oracle.jsonl:closedloop.jsonl [more ...] > all_metrics_test.txt
  (same SPECS as run_6d.sh; also writes all_metrics_test.csv)

For every condition and coordinator: mean per replay of every metric, and for each coordinator the paired
difference to the reactive broadcast with a 95% scene-bootstrap interval (B = 2000, same routine as the paper).
Uses only replays present for all coordinators, exactly as paperA_table.py does.
"""
import sys, csv, argparse, numpy as np
from compare_oracle import load, boot

PRIM, NOM = 'oracle_l0.25_H15_nocoord', 'nominal_l0.25_H15_M6'
METRICS = ['ev_delay', 'ev_speed', 'ev_stops', 'ev_hb', 'commands', 'disturbed', 'civ_conflicts', 'civ_near', 'lost_m', 'coll_sim']
ap = argparse.ArgumentParser(); ap.add_argument('--jit', required=True); ap.add_argument('specs', nargs='+')
a = ap.parse_args()
POLS = [('reactive', 'reactive'), (PRIM, 'oracle'), (NOM, 'nominal'), (a.jit, a.jit), ('pace_eva', 'PACE-EVA'), ('nocoord', 'nocoord')]

rows = []
for spec in a.specs:
    tag, rho, fo, fc = spec.split(':', 3)
    O, C = load(fo), load(fc)
    both = [k for k in O if k in C]
    M = {k: dict(C[k], **{p: r for p, r in O[k].items() if p not in ('nocoord', 'reactive')}) for k in both}
    keys = [k for k in M if all(p in M[k] for p, _ in POLS)]
    if not keys: print(f'{tag} {rho}: no complete replays'); continue
    miss = [m for m in METRICS if any(m not in M[keys[0]][p] for p, _ in POLS)]
    if miss: print(f'{tag} {rho}: metrics not in the files: {miss}')
    mets = [m for m in METRICS if m not in miss]
    sc = [k[0] for k in keys]
    print(f'\n=== {tag} rho={rho}  n={len(keys)} replays, {len(set(sc))} scenes')
    print('%-10s' % 'coord' + ''.join('%15s' % m for m in mets))
    for p, nm in POLS:
        mean = {m: np.mean([M[k][p][m] for k in keys]) for m in mets}
        print('%-10s' % nm + ''.join('%15.3f' % mean[m] for m in mets))
        for m in mets:
            if p == 'reactive':
                d = (0.0, 0.0, 0.0)
            else:
                d = boot(np.array([M[k][p][m] - M[k]['reactive'][m] for k in keys], float), sc)
            rows.append(dict(model=tag, rho=rho, n=len(keys), coordinator=nm, metric=m, mean=round(mean[m], 4),
                             diff_vs_reactive=round(d[0], 4), ci_lo=round(d[1], 4), ci_hi=round(d[2], 4),
                             clear=int(d[1] > 0 or d[2] < 0)))
    print('%-10s' % 'diff vs reactive [95% CI], * = clear')
    for p, nm in POLS[1:]:
        cells = [r for r in rows if r['model'] == tag and r['rho'] == rho and r['coordinator'] == nm]
        print('  %-8s ' % nm + '  '.join('%s %+.3f [%+.3f,%+.3f]%s' % (r['metric'], r['diff_vs_reactive'], r['ci_lo'], r['ci_hi'], '*' if r['clear'] else '')
                                       for r in cells if r['metric'] in ('civ_conflicts', 'civ_near', 'ev_stops', 'ev_hb', 'coll_sim', 'commands', 'disturbed')))

with open('all_metrics_test.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
print('\nwrote all_metrics_test.csv with', len(rows), 'rows')
