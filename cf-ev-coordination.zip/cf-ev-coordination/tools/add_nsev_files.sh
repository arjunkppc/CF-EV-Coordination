#!/bin/bash
# Copies the NS-EV modules this repository needs but does not yet contain, from your NS-EV working folder.
#   bash tools/add_nsev_files.sh /path/to/your/nsev
# Only source code is copied; data, logs and trained models stay where they are.
set -e
SRC=${1:?usage: bash tools/add_nsev_files.sh /path/to/nsev}
DST="$(cd "$(dirname "$0")/.." && pwd)/ns_ev"
for f in features.py sim.py model.py summarize_cl.py; do
  if [ -f "$SRC/$f" ]; then cp "$SRC/$f" "$DST/"; echo "copied $f"; else echo "NOT FOUND: $SRC/$f"; fi
done
python3 "$(dirname "$0")/check_repo.py"
