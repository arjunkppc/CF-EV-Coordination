"""Pre-publication check: every module the code imports is present, scripts compile, no personal paths remain,
and no data or model files are about to be committed. Run from anywhere: python3 tools/check_repo.py"""
import os, re, sys, py_compile, subprocess
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
local = {os.path.splitext(f)[0] for d in ('ns_ev', 'coordination', 'analysis', 'paper_figures') for f in os.listdir(os.path.join(ROOT, d)) if f.endswith('.py')}
third = {'numpy', 'nuscenes', 'matplotlib', 'torch', 'scipy', 'sklearn', 'pickle'}
stdlib = set(sys.stdlib_module_names)
bad = []
for d in ('ns_ev', 'coordination', 'analysis', 'paper_figures', 'tools'):
    for f in sorted(os.listdir(os.path.join(ROOT, d))):
        p = os.path.join(ROOT, d, f)
        if f.endswith('.py'):
            try: py_compile.compile(p, doraise=True)
            except py_compile.PyCompileError as e: bad.append(f'does not compile: {d}/{f}: {e}')
            for m in re.findall(r'^\s*(?:from|import)\s+([A-Za-z_]\w*)', open(p).read(), re.M):
                if m not in local and m not in stdlib and m not in third:
                    bad.append(f'{d}/{f} imports "{m}", which is not in the repository')
        if os.path.isfile(p) and f != 'check_repo.py':
            txt = open(p, errors='ignore').read()
            for pat in (r'/home/\w+', r'g700515', r'ARJUN'):
                if re.search(pat, txt): bad.append(f'personal path "{pat}" in {d}/{f}')
for f in ('features.py', 'sim.py', 'model.py'):
    if not os.path.exists(os.path.join(ROOT, 'ns_ev', f)): bad.append(f'missing ns_ev/{f} (run tools/add_nsev_files.sh)')
for dp, _, fs in os.walk(ROOT):
    if '.git' in dp: continue
    for f in fs:
        if f.endswith(('.jsonl', '.pkl', '.npz', '.log')) or os.path.getsize(os.path.join(dp, f)) > 20e6:
            bad.append(f'data/model/large file present (ignored by .gitignore, check): {os.path.relpath(os.path.join(dp, f), ROOT)}')
print('\n'.join(sorted(set(bad))) if bad else 'repository check passed')
sys.exit(1 if any('missing' in b or 'not in the repository' in b or 'compile' in b or 'personal' in b for b in bad) else 0)
