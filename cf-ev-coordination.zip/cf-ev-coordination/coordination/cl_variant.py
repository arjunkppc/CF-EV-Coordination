"""
cf-ev-coordination / cl_variant.py - run the NS-EV study's nsev_closedloop.py UNCHANGED under a different driver-response model and/or
imperfect obedience (--p_ignore). The module is loaded as a library, its Replay class is patched exactly as in
oracle_test.py, and its own __main__ block is then executed, so nocoord / reactive / PACE-* run as in the NS-EV study.

  python cl_variant.py --nsev_dir ../ns_ev [--react_mu 2.2 ...] [--p_ignore 0.2] -- \
         --dataroot ... --split val --rho 0.5 --injections 3 --t_lead 15 --theta_r 0.3 --eva ... --out ...
"""
import sys, os, runpy, argparse
ap = argparse.ArgumentParser()
ap.add_argument('--nsev_dir', default=os.environ.get('NSEV_DIR', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'ns_ev')))
for k in ['dp_lo', 'dp_hi', 'late_lo', 'late_hi', 'react_mu', 'freeze_p', 'shift']: ap.add_argument('--' + k, type=float)
ap.add_argument('--p_ignore', type=float, default=0.0)
argv = sys.argv[1:]; cut = argv.index('--')
a = ap.parse_args(argv[:cut])
nsev = os.path.abspath(os.path.expanduser(a.nsev_dir)); sys.path.insert(0, nsev)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nsev_pipeline as P
P.RESP.update({k: v for k, v in vars(a).items() if k not in ('nsev_dir', 'p_ignore') and v is not None})
print('driver-response model:', P.RESP, '| p_ignore', a.p_ignore, flush=True)
path = os.path.join(nsev, 'nsev_closedloop.py')
ns = runpy.run_path(path, run_name='nsev_cl_lib')          # definitions only (main block not executed)
if a.p_ignore > 0:
    import obey; obey.apply(ns['Replay'], a.p_ignore)
g = ns['run_replay'].__globals__                           # the module's real namespace
src = open(path).read(); main = src[src.index("if __name__ == '__main__':"):]
sys.argv = [path] + argv[cut + 1:]; g['__name__'] = '__main__'
exec(compile(main, path, 'exec'), g)
