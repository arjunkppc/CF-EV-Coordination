"""
cf-ev-coordination / obey.py - imperfect obedience: a commanded CV ignores the command with probability p.

Whether driver j ignores is a fixed trait of that driver in that replay (drawn from (seed, j)), so it is identical
for every policy and every fork, and the paired design is kept. An ignored command is still counted as sent
(m['commands']); the driver then keeps behaving as a human (may still yield on seeing the EV) and is not offered
again as a command candidate. apply() patches the Replay class in place; calling it again only changes p.
"""
import numpy as np


def apply(Replay, p):
    if hasattr(Replay, '_obey_p'): Replay._obey_p = float(p); return
    init0, cmd0, corr0 = Replay.__init__, Replay.command_yield, Replay.corridor_cvs

    def __init__(self, times, tracks, seed, *a, **k):
        init0(self, times, tracks, seed, *a, **k); self._oseed = int(seed); self._ign = set()

    def command_yield(self, j):
        p_ = getattr(self, '_p_override', type(self)._obey_p)
        if p_ > 0 and np.random.default_rng([self._oseed, int(j), 4242]).uniform() < p_:
            self._ign.add(j); self.m['commands'] += 1; self.m['cmd_ignored'] = self.m.get('cmd_ignored', 0) + 1
            return
        cmd0(self, j)

    def corridor_cvs(self, R):
        return [j for j in corr0(self, R) if j not in self._ign]

    Replay.__init__, Replay.command_yield, Replay.corridor_cvs = __init__, command_yield, corridor_cvs
    Replay._obey_p = float(p)
