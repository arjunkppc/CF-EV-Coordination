"""
cf-ev-coordination / cf_fork.py - pause-and-copy for NS-EV closed-loop replays.

A Replay (nsev_closedloop.Replay) draws all its random numbers (driver traits, CV assignment) in __init__;
Replay.step() is deterministic. So a copy of a Replay taken at step k continues exactly as the original would,
and two copies given different commands at step k give the paired counterfactual outcomes of those commands.

fork(rp)            -> independent copy (static scene data shared, mutable state copied)
rollout(rp, pol, k) -> run a copy forward to step k under a policy, return it
snapshot(rp)        -> the running totals needed to measure what happened between two moments
delta(a, b)         -> outcome between snapshot a and snapshot b (EV progress, disruption, conflicts, ...)
"""
import copy
import numpy as np

# never modified after __init__ -> shared between forks (saves memory and time)
SHARED = {'grid', 'ids', 'tr', 'route', 'lens', 'comply', 'freeze', 'dperc', 'react', 'is_cv', 'side', 'ev_v0', 'N', 'ok'}


def fork(rp):
    c = copy.copy(rp)
    for name, v in rp.__dict__.items():
        if name in SHARED: continue
        if isinstance(v, np.ndarray): setattr(c, name, v.copy())
        elif isinstance(v, set): setattr(c, name, set(v))
        elif isinstance(v, list): setattr(c, name, list(v))          # frames: arrays are never edited in place
        elif isinstance(v, dict): setattr(c, name, {k: (set(x) if isinstance(x, set) else copy.copy(x)) for k, x in v.items()})
    return c


def rollout(rp, policy, k_end, fc=None):
    """Advance a fork to step k_end (or scene end). Policies act every 0.5 s, exactly as in run_replay."""
    r = fork(rp)
    k_end = min(k_end, len(r.grid))
    while r.k < k_end:
        if policy is not None and r.k % 5 == 0 and r.k > 0: policy(r, fc)
        r.step()
    return r


def snapshot(rp):
    m = rp.m
    return dict(k=rp.k, se=float(rp.se), lost=float(m['lost_m']), cmd=m['commands'], conf=len(m['conf_pairs']),
                near=len(m['near_pairs']), coll=m['coll_sim'], hb=m['ev_hb'], stops=m['ev_stops'],
                disturbed=len(m['disturbed']))


def delta(a, b):
    return {k: b[k] - a[k] for k in a}


# ----------------------------------------------------------------- cost used by the oracle
def cost(d, lam):
    """Lower is better. Progress in metres; disruption D in 'metre-equivalents':
         D = civilian metres lost vs. log + 10 per new civilian conflict + 3 per near miss + 2 per command.
       lam trades EV progress against disruption (lam=0: pure EV speed). Collisions caused by simulated
       vehicles and EV hard brakes are always heavily penalised."""
    D = d['lost'] + 10.0 * d['conf'] + 3.0 * d['near'] + 2.0 * d['cmd']
    return -d['se'] + lam * D + 1000.0 * d['coll'] + 5.0 * d['hb']
