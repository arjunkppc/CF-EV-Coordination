"""
cf-ev-coordination / cf_generate.py - Step 5: the paired counterfactual dataset.

For every recorded decision point (0.5-s cycle with candidate connected vehicles ahead of the EV) we branch the
replay exactly as the oracle does - no command / command car j (each candidate) / command all - and run every
branch 6 s ahead with the true driver-response model. Each decision therefore gives the SAME starting moment with
up to A different futures: the effect of each command on every nearby car.

Which branch the scene then continues with is drawn at random (seeded), so the dataset covers states reached
after many different command histories, not only those of one policy.

Saved per decision d (arrays padded to NMAX nearby cars; the EV is always the last slot, index NMAX):
  hist   [d, 4, NMAX+1, 3]     last 4 frames (0.5 s apart, as fed to EVA-Net in the NS-EV study): s, d, v  (NaN = absent)
  now    [d, NMAX+1, 3]        state at the decision moment (s, d, v)
  fut    [d, A, 13, NMAX+1, 3] per branch: frames written at the decision step and +0.5, ..., +6.0 s later.
                               fut[:, :, 0] already includes one 0.1-s step of the command (branches may differ
                               there by < 1 m); use fut[:, :, 1:] (12 frames, +0.5 ... +6.0 s) as the future.
  act    [d, A, NMAX] bool     cars commanded in each branch;  act_ok [d, A] bool (branch exists)
  out    [d, A, 8]             branch outcome over 6 s: EV progress (m), civilian metres lost, commands,
                               new conflicts, new near misses, sim collisions, EV hard brakes, cars disturbed
  mask   [d, NMAX] bool        slot holds a real car;   cand [d, NMAX] bool  car is a command candidate
  trait  [d, NMAX, 8]          HIDDEN (analysis only, never a model input): is_cv, complies, freezes,
                               perception range, reaction time, already taken over, kind, time aware (-1 = no)
  meta   [d, 6]                scene index (into scene_names), injection, rho, step k, side, seed
Shards: <out>_shardNNN.npz, plus <out>_done.txt for resuming and <out>_stats.json.

Usage (from coordination/):
  python cf_generate.py --nsev_dir ../ns_ev --dataroot /path/to/nuscenes \
         --split train_fit --rhos 0.25,0.5,1.0 --injections 2 --out cf_train --workers 8
"""
import argparse, json, os, sys, time, glob
import numpy as np

A_MAX, NFUT, NOUT = 8, 13, 8
OUT_KEYS = ['se', 'lost', 'cmd', 'conf', 'near', 'coll', 'hb', 'disturbed']


def setup(nsev_dir):
    sys.path.insert(0, os.path.abspath(os.path.expanduser(nsev_dir)))
    global CL, P
    import nsev_closedloop as CL
    import nsev_pipeline as P


from cf_fork import fork, snapshot, delta


def frame_rows(fr, idx, N, nmax):
    """frame [N+1,3] (1e6 = absent) -> [nmax+1,3] for the chosen cars + EV, NaN for absent/padding."""
    o = np.full((nmax + 1, 3), np.nan, np.float32)
    if idx: o[:len(idx)] = fr[idx]
    o[nmax] = fr[N]
    o[o > 1e5] = np.nan
    return o


def record(rp, cands, a, nmax):
    N, se = rp.N, rp.se
    near = [m for m in range(N) if not np.isnan(rp.s_i[m]) and -20 < rp.s_i[m] - se < CL.R_CTRL + 30]
    near = sorted(near, key=lambda m: rp.s_i[m] - se)
    idx = list(cands) + [m for m in near if m not in cands]
    idx = idx[:nmax]; slot = {m: i for i, m in enumerate(idx)}
    acts = [()] + [(j,) for j in cands] + ([tuple(cands)] if len(cands) > 1 else [])
    hist = np.full((4, nmax + 1, 3), np.nan, np.float32)          # NaN-padded at the front early in a scene
    hf = rp.frames[-4:]
    if hf: hist[4 - len(hf):] = np.stack([frame_rows(f, idx, N, nmax) for f in hf])
    now = np.full((nmax + 1, 3), np.nan, np.float32)
    now[:len(idx)] = np.c_[rp.s_i[idx], rp.d_i[idx], rp.vnow[idx]]; now[nmax] = [se, 0.0, rp.ve]
    fut = np.full((A_MAX, NFUT, nmax + 1, 3), np.nan, np.float32)
    act = np.zeros((A_MAX, nmax), bool); ok = np.zeros(A_MAX, bool); out = np.zeros((A_MAX, NOUT), np.float32)
    s0 = snapshot(rp)
    for ai, ac in enumerate(acts[:A_MAX]):
        f = fork(rp); n0 = len(f.frames)
        for j in ac: f.command_yield(j); act[ai, slot[j]] = True
        k_end = min(f.k + 5 * (NFUT - 1) + 1, len(f.grid))
        while f.k < k_end: f.step()                     # base continuation: no further commands
        frs = f.frames[n0:n0 + NFUT]
        for ti, fr in enumerate(frs): fut[ai, ti] = frame_rows(fr, idx, N, nmax)
        d = delta(s0, snapshot(f)); out[ai] = [d[k] for k in OUT_KEYS]; ok[ai] = True
    mask = np.zeros(nmax, bool); mask[:len(idx)] = True
    cand = np.zeros(nmax, bool); cand[:len(cands)] = True
    tr = np.zeros((nmax, 8), np.float32)
    if idx:
        ii = np.array(idx)
        tr[:len(idx)] = np.c_[rp.is_cv[ii], rp.comply[ii], rp.freeze[ii], rp.dperc[ii], rp.react[ii],
                              rp.taken[ii], rp.kind[ii], rp.aware_t[ii]]
    return dict(hist=hist, now=now, fut=fut, act=act, act_ok=ok, out=out, mask=mask, cand=cand, trait=tr), acts


def job(arg):
    (si, name, side, times, tracks, inj, seed, back, rho, a) = arg
    rp = CL.Replay(times, tracks, seed, rho, side, a.compliance, back)
    if not rp.ok: return si, inj, rho, []
    rng = np.random.default_rng(seed * 31 + int(rho * 100))   # behaviour (which branch continues), reproducible
    recs, n_dec = [], 0
    while not rp.done():
        if rp.k % 5 == 0 and rp.k > 0:
            c = rp.corridor_cvs(CL.R_CTRL)
            if c:
                c = sorted(c, key=lambda j: rp.s_i[j] - rp.se)[:a.max_cand]
                acts = [()] + [(j,) for j in c] + ([tuple(c)] if len(c) > 1 else [])
                if n_dec % a.every == 0:
                    r, acts = record(rp, c, a, a.nmax)
                    r['meta'] = np.array([si, inj, rho, rp.k, side, seed], np.float64); recs.append(r)
                n_dec += 1
                for j in acts[rng.integers(len(acts))]: rp.command_yield(j)
        rp.step()
    return si, inj, rho, recs


def flush(buf, out, n):
    if not buf: return n
    Z = {k: np.stack([r[k] for r in buf]) for k in buf[0]}
    np.savez_compressed(f'{out}_shard{n:03d}.npz', **Z)
    return n + 1


def _init(nsev_dir): setup(nsev_dir)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--nsev_dir', default=os.environ.get('NSEV_DIR', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'ns_ev')))
    ap.add_argument('--dataroot', required=True); ap.add_argument('--version', default='v1.0-trainval')
    ap.add_argument('--split', default='train_fit', choices=['train_fit', 'train_holdout', 'val', 'all'])
    ap.add_argument('--rhos', default='0.25,0.5,1.0'); ap.add_argument('--injections', type=int, default=2)
    ap.add_argument('--compliance', type=float, default=0.7); ap.add_argument('--max_scenes', type=int, default=0)
    ap.add_argument('--max_cand', type=int, default=6); ap.add_argument('--nmax', type=int, default=24)
    ap.add_argument('--every', type=int, default=1, help='record every n-th decision point (still act at all)')
    ap.add_argument('--seed_base', type=int, default=0); ap.add_argument('--shard_size', type=int, default=2000)
    ap.add_argument('--workers', type=int, default=8); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    if a.split == 'val' and not os.environ.get('CF_ALLOW_TEST'):
        sys.exit('refusing to build training data on the TEST scenes (nuScenes val); set CF_ALLOW_TEST=1 for an eval-only set')
    setup(a.nsev_dir)
    from nuscenes.nuscenes import NuScenes
    nusc = NuScenes(a.version, os.path.expanduser(a.dataroot), verbose=False)
    if a.split == 'all': scenes = nusc.scene
    else:
        from nuscenes.utils.splits import create_splits_scenes
        sp = create_splits_scenes()
        if a.split in ('train_fit', 'train_holdout'):        # identical to nsev_pipeline.py's 90/10 split
            tr = sorted(sp['train']); hold = set(tr[::10])
            names = hold if a.split == 'train_holdout' else set(tr) - hold
        else: names = set(sp[a.split])
        scenes = [s for s in nusc.scene if s['name'] in names]
    if a.max_scenes: scenes = scenes[:a.max_scenes]
    done = set()
    if os.path.exists(a.out + '_done.txt'):
        done = {tuple(l.split()) for l in open(a.out + '_done.txt') if l.strip()}
    rhos = [float(x) for x in a.rhos.split(',')]
    jobs, n_skip = [], 0
    for si, sc in enumerate(scenes):
        loc = nusc.get('log', sc['log_token'])['location']; side = +1 if loc.startswith('singapore') else -1
        todo = [(inj, rho) for inj in range(a.injections) for rho in rhos if (str(si), str(inj), f'{rho:g}') not in done]
        if not todo: continue
        times, tracks = P.load_scene_tracks(nusc, sc)
        for inj in sorted({t[0] for t in todo}):
            seed = a.seed_base + 7919 * si + inj; back = np.random.default_rng(seed + 5).uniform(40, 100)
            base = CL.run_replay(times, tracks, seed, 0.0, side, a.compliance, back, None, None)   # validity filter
            if base is None or base['spawn_conflict'] or base['collisions'] > 0:
                n_skip += 1
                with open(a.out + '_done.txt', 'a') as f:
                    for rho in rhos: f.write(f'{si} {inj} {rho:g}\n')
                continue
            for (i2, rho) in todo:
                if i2 == inj: jobs.append((si, sc['name'], side, times, tracks, inj, seed, back, rho, a))
    json.dump([s['name'] for s in scenes], open(a.out + '_scene_names.json', 'w'))
    del nusc
    print(f'{len(scenes)} scenes, {len(jobs)} replays to run ({n_skip} replays failed the validity filter)', flush=True)
    n_shard = len(glob.glob(a.out + '_shard*.npz')); buf, pend = [], []; t0 = time.time(); n_dec = 0
    if a.workers > 1:
        import multiprocessing as mp
        it = mp.get_context('fork').Pool(a.workers, initializer=_init, initargs=(a.nsev_dir,)).imap_unordered(job, jobs)
    else: it = map(job, jobs)
    for n, (si, inj, rho, recs) in enumerate(it, 1):
        buf += recs; pend.append(f'{si} {inj} {rho:g}'); n_dec += len(recs)
        if len(buf) >= a.shard_size or n == len(jobs):
            n_shard = flush(buf, a.out, n_shard); buf = []
            with open(a.out + '_done.txt', 'a') as f: f.write(''.join(p + '\n' for p in pend))
            pend = []
        if n % 20 == 0 or n == len(jobs): print(f'{n}/{len(jobs)} replays, {n_dec} decisions, {time.time() - t0:.0f}s', flush=True)
    # dataset statistics over all shards: does the command actually change what happens?
    D = [dict(np.load(f)) for f in sorted(glob.glob(a.out + '_shard*.npz'))]
    if D:
        out = np.concatenate([d['out'] for d in D]); ok = np.concatenate([d['act_ok'] for d in D])
        meta = np.concatenate([d['meta'] for d in D]); nb = ok.sum(1)
        se = np.where(ok, out[..., 0], np.nan); lost = np.where(ok, out[..., 1], np.nan)
        st = dict(decisions=int(len(out)), replays=int(len({tuple(m[[0, 1, 2]]) for m in meta})),
                  branches_mean=float(nb.mean()),
                  by_rho={f'{r:g}': int((meta[:, 2] == r).sum()) for r in rhos},
                  ev_progress_spread_m=float(np.nanmean(np.nanmax(se, 1) - np.nanmin(se, 1))),
                  lost_spread_m=float(np.nanmean(np.nanmax(lost, 1) - np.nanmin(lost, 1))),
                  share_decisions_where_command_changes_outcome=float(np.mean(
                      (np.nanmax(se, 1) - np.nanmin(se, 1) > 0.05) | (np.nanmax(lost, 1) - np.nanmin(lost, 1) > 0.05))))
        json.dump(st, open(a.out + '_stats.json', 'w'), indent=1); print(json.dumps(st, indent=1))
    print('done', a.out)
