"""
cf-ev-coordination / oracle_test.py - Step 0: is perfect "what if" knowledge worth anything to the coordinator?

At every 0.5-s decision point with candidate connected vehicles (CVs) ahead of the EV, the ORACLE
  1. forks the replay once per candidate action: no command / command CV j (each nearby candidate) / command all,
  2. runs each fork H seconds ahead with the TRUE driver-response model (the same hidden traits the scene uses),
  3. picks the action with the lowest cost (cf_fork.cost: EV progress vs. disruption, weight lam).
Forks continue under a fixed base policy (no further commands, or the reactive rule), so the oracle is a one-step
lookahead "rollout" policy over the base policy.

Everything else is identical to the NS-EV study's nsev_closedloop.py: same scenes, same seeds (7919*scene_index + inj),
same validity filter, same rho. Results therefore pair one-to-one with the NS-EV study's cl_test_rho*.jsonl
(nocoord / reactive / pace_*), joined on (scene, inj).

Usage (from coordination/):
  python oracle_test.py --nsev_dir ../ns_ev --dataroot /path/to/nuscenes \
      --split val --rho 0.5 --injections 3 --lams 0,0.25,1 --horizon 8 --base nocoord \
      --out or_test_rho0.5.jsonl --dec_out or_dec_rho0.5.jsonl --workers 8
"""
import argparse, json, os, sys, time, math
import numpy as np


RESP_KEYS = ['dp_lo', 'dp_hi', 'late_lo', 'late_hi', 'react_mu', 'freeze_p', 'shift']


def setup(nsev_dir, resp=None, p_ignore=0.0):
    """Import the NS-EV study's code; optionally override the driver-response model (P.RESP), as nsev_pipeline.py's
    --dp_lo ... --shift flags do. Overrides are applied in every worker process too."""
    sys.path.insert(0, os.path.abspath(os.path.expanduser(nsev_dir)))
    global CL, P
    import nsev_closedloop as CL
    import nsev_pipeline as P
    if resp: P.RESP.update(resp)
    if p_ignore > 0 or hasattr(CL.Replay, '_obey_p'):
        import obey; obey.apply(CL.Replay, p_ignore)


from cf_fork import fork, snapshot, delta, cost


class Oracle:
    """Callable policy with the same signature as nsev_closedloop policies: policy(rp, fc)."""
    def __init__(self, lam, horizon_s, base, max_cand=6, log=None):
        self.lam, self.H, self.max_cand, self.log = lam, int(round(horizon_s / 0.1)), max_cand, log
        self.base = None if base == 'nocoord' else CL.policy_reactive
        self.tag = None; self.n_eval = 0

    def _roll(self, rp, actions):
        f = fork(rp)
        for j in actions: f.command_yield(j)
        k0, k_end = f.k, min(f.k + self.H, len(f.grid))
        while f.k < k_end:
            if self.base is not None and f.k % 5 == 0 and f.k > k0: self.base(f, None)   # base acts from the NEXT cycle
            f.step()
        self.n_eval += 1
        return f

    def __call__(self, rp, fc=None):
        c = rp.corridor_cvs(CL.R_CTRL)
        if not c: return
        c = sorted(c, key=lambda j: rp.s_i[j] - rp.se)[:self.max_cand]
        acts = [()] + [(j,) for j in c] + ([tuple(c)] if len(c) > 1 else [])
        s0 = snapshot(rp); res = []
        for a in acts:
            d = delta(s0, snapshot(self._roll(rp, a)))
            res.append((cost(d, self.lam), len(a), a, d))
        best = min(res, key=lambda r: (round(r[0], 6), r[1]))          # tie -> fewer commands
        for j in best[2]: rp.command_yield(j)
        if self.log is not None:
            pi = getattr(type(rp), '_obey_p', 0.0)
            ctr = [dict(comply=bool(rp.comply[j]), freeze=bool(rp.freeze[j]), dperc=round(float(rp.dperc[j]), 1),
                        react=round(float(rp.react[j]), 2), aware=bool(rp.aware_t[j] >= 0),
                        ignores=bool(pi > 0 and np.random.default_rng([rp._oseed, int(j), 4242]).uniform() < pi),
                        free_now=bool(rp.target_free_now(j)), v=round(float(rp.vnow[j]), 2)) for j in c]
            self.log.append(dict(tag=self.tag, ctr=ctr, k=int(rp.k), t=round(float(rp.grid[rp.k]), 1), ev_s=round(float(rp.se), 2),
                                 ev_v=round(float(rp.ve), 2), cands=[int(j) for j in c],
                                 gaps=[round(float(rp.s_i[j] - rp.se), 1) for j in c],
                                 actions=[[int(j) for j in r[2]] for r in res], costs=[round(r[0], 3) for r in res],
                                 outcomes=[{k: round(float(v), 3) for k, v in r[3].items()} for r in res],
                                 chosen=[int(j) for j in best[2]]))


NOMINAL = dict(compliance=0.7, dp_lo=60.0, dp_hi=140.0, late_lo=18.0, late_hi=35.0, react_mu=1.4, freeze_p=0.18)


class Nominal(Oracle):
    """Deployable model-predictive coordinator: identical branching to the Oracle, but each fork replaces the
    hidden traits of every vehicle not yet visibly reacting (not 'taken') with a draw from the NS-EV DEFAULT
    population model (NOMINAL), whatever the true driver model is, and assumes commands are obeyed. Costs are
    averaged over M draws (common random numbers across actions). Known: positions, speeds, which vehicles are CVs,
    which vehicles are already reacting, and which CVs have already ignored a command."""
    def __init__(self, lam, horizon_s, base, M=6, max_cand=6, log=None):
        super().__init__(lam, horizon_s, base, max_cand, log); self.M = M

    def _sample(self, f, rng):
        N, nm = f.N, NOMINAL; free = ~f.taken
        prompt = rng.uniform(size=N) < nm['compliance']; late = (~prompt) & (rng.uniform(size=N) < 0.75)
        comply = prompt | late; freeze = comply & (rng.uniform(size=N) < nm['freeze_p'])
        dperc = np.where(late, rng.uniform(nm['late_lo'], nm['late_hi'], N), rng.uniform(nm['dp_lo'], nm['dp_hi'], N))
        react = np.clip(rng.lognormal(math.log(nm['react_mu']), 0.45, N), 0.4, 6.0) + 0.8 * late
        f.comply = np.where(free, comply, f.comply); f.freeze = np.where(free, freeze, f.freeze)   # new arrays: shared
        f.dperc = np.where(free, dperc, f.dperc); f.react = np.where(free, react, f.react)           # originals untouched
        f._p_override = 0.0

    def __call__(self, rp, fc=None):
        c = rp.corridor_cvs(CL.R_CTRL)
        if not c: return
        c = sorted(c, key=lambda j: rp.s_i[j] - rp.se)[:self.max_cand]
        acts = [()] + [(j,) for j in c] + ([tuple(c)] if len(c) > 1 else [])
        s0 = snapshot(rp); tot = np.zeros(len(acts))
        for m in range(self.M):
            for ai, a in enumerate(acts):
                f = fork(rp); self._sample(f, np.random.default_rng([getattr(rp, '_rseed', 0), rp.k, m, 77]))
                for j in a: f.command_yield(j)
                k0, k_end = f.k, min(f.k + self.H, len(f.grid))
                while f.k < k_end:
                    if self.base is not None and f.k % 5 == 0 and f.k > k0: self.base(f, None)
                    f.step()
                self.n_eval += 1; tot[ai] += cost(delta(s0, snapshot(f)), self.lam)
        best = min(range(len(acts)), key=lambda i: (round(tot[i] / self.M, 6), len(acts[i])))
        for j in acts[best]: rp.command_yield(j)


def run(times, tracks, seed, rho, side, compliance, back, policy):
    rp = CL.Replay(times, tracks, seed, rho, side, compliance, back)
    if not rp.ok: return None
    rp._rseed = int(seed)
    t0 = time.perf_counter(); lat = []
    while not rp.done():
        if policy is not None and rp.k % 5 == 0 and rp.k > 0:
            a = time.perf_counter(); policy(rp, None); lat.append(time.perf_counter() - a)
        rp.step()
    r = rp.result(); r['cmd_ignored'] = int(rp.m.get('cmd_ignored', 0)); r['plan_ms'] = round(1000 * float(np.median(lat)), 2) if lat else 0.0
    r['wall_s'] = round(time.perf_counter() - t0, 2)
    return r


def job(arg):
    """One (scene, injection): baseline validity filter, then nocoord, reactive and every oracle variant."""
    (name, loc, side, times, tracks, inj, seed, back, a, todo) = arg
    rows, decs = [], []
    base = run(times, tracks, seed, a.rho, side, a.compliance, back, None)
    if base is None or base['spawn_conflict'] or base['collisions'] > 0: return rows, decs   # same filter as the NS-EV study
    for pol in todo:
        if pol == 'nocoord': r = base
        elif pol == 'reactive': r = run(times, tracks, seed, a.rho, side, a.compliance, back, CL.policy_reactive)
        elif pol.startswith('nominal'):
            lam = float(pol.split('_l')[1].split('_')[0]); H = float(pol.split('_H')[1].split('_')[0]); M = int(pol.split('_M')[1])
            o = Nominal(lam, H, 'nocoord', M, a.max_cand)
            r = run(times, tracks, seed, a.rho, side, a.compliance, back, o); r['n_rollouts'] = o.n_eval
        elif pol.startswith('jit'):
            import baselines as B; T = float(pol[3:])
            r = run(times, tracks, seed, a.rho, side, a.compliance, back, lambda rp, fc: B.policy_jit(rp, fc, CL, P, T))
        else:
            lam = float(pol.split('_l')[1].split('_')[0])
            o = Oracle(lam, a.horizon, a.base, a.max_cand, decs if a.dec_out else None); o.tag = [name, inj, pol]
            r = run(times, tracks, seed, a.rho, side, a.compliance, back, o); r['n_rollouts'] = o.n_eval
        rows.append(dict(r, scene=name, location=loc, inj=inj, policy=pol, rho=a.rho, compliance=a.compliance,
                         horizon=a.horizon, base=a.base))
    return rows, decs


def _init(nsev_dir, resp, p_ignore): setup(nsev_dir, resp, p_ignore)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--nsev_dir', default=os.environ.get('NSEV_DIR', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'ns_ev')))
    ap.add_argument('--dataroot', required=True); ap.add_argument('--version', default='v1.0-trainval')
    ap.add_argument('--split', default='val'); ap.add_argument('--rho', type=float, default=0.5)
    ap.add_argument('--injections', type=int, default=3); ap.add_argument('--compliance', type=float, default=0.7)
    ap.add_argument('--max_scenes', type=int, default=0)
    ap.add_argument('--lams', default='0,0.25,1'); ap.add_argument('--horizon', type=float, default=8.0)
    ap.add_argument('--base', default='nocoord', choices=['nocoord', 'reactive'])
    ap.add_argument('--max_cand', type=int, default=6); ap.add_argument('--workers', type=int, default=8)
    ap.add_argument('--out', required=True); ap.add_argument('--dec_out', default='')
    for k_ in RESP_KEYS: ap.add_argument('--' + k_, type=float, default=None)
    ap.add_argument('--p_ignore', type=float, default=0.0, help='probability a commanded CV ignores the command')
    ap.add_argument('--extra', default='', help='comma-separated extra policies, e.g. jit4')
    a = ap.parse_args()
    resp = {k_: getattr(a, k_) for k_ in RESP_KEYS if getattr(a, k_) is not None}
    setup(a.nsev_dir, resp, a.p_ignore)
    print('driver-response model:', P.RESP, '| compliance', a.compliance, '| p_ignore', a.p_ignore, flush=True)
    from nuscenes.nuscenes import NuScenes
    pols = ['nocoord', 'reactive'] + [f'oracle_l{float(l):g}_H{a.horizon:g}_{a.base}' for l in a.lams.split(',') if l] \
           + [x for x in a.extra.split(',') if x]
    nusc = NuScenes(a.version, os.path.expanduser(a.dataroot), verbose=False)
    if a.split == 'all': scenes = nusc.scene
    else:
        from nuscenes.utils.splits import create_splits_scenes
        sp = create_splits_scenes()
        names = set(sorted(sp['train'])[::10]) if a.split == 'train_holdout' else set(sp[a.split])
        scenes = [s for s in nusc.scene if s['name'] in names]
    if a.max_scenes: scenes = scenes[:a.max_scenes]
    done = set()
    if os.path.exists(a.out):
        for l in open(a.out): r = json.loads(l); done.add((r['scene'], r['inj'], r['policy']))
    jobs = []
    for si, sc in enumerate(scenes):                        # si and seeds exactly as in nsev_closedloop.py
        loc = nusc.get('log', sc['log_token'])['location']; side = +1 if loc.startswith('singapore') else -1
        times, tracks = P.load_scene_tracks(nusc, sc)
        for inj in range(a.injections):
            todo = [p for p in pols if (sc['name'], inj, p) not in done]
            if not todo: continue
            seed = 7919 * si + inj; back = np.random.default_rng(seed + 5).uniform(40, 100)
            jobs.append((sc['name'], loc, side, times, tracks, inj, seed, back, a, todo))
    del nusc
    print(f'{len(scenes)} scenes, {len(jobs)} replays to run, policies {pols}', flush=True)
    t0 = time.time()
    if a.workers > 1:
        import multiprocessing as mp
        pool = mp.get_context('fork').Pool(a.workers, initializer=_init, initargs=(a.nsev_dir, resp, a.p_ignore))
        it = pool.imap_unordered(job, jobs)
    else: it = map(job, jobs)
    for n, (rows, decs) in enumerate(it, 1):
        with open(a.out, 'a') as f:
            for r in rows: f.write(json.dumps(r) + '\n')
        if a.dec_out and decs:
            with open(a.dec_out, 'a') as f:
                for d in decs: f.write(json.dumps(d) + '\n')
        if n % 10 == 0 or n == len(jobs): print(f'{n}/{len(jobs)} replays, {time.time() - t0:.0f}s', flush=True)
    print('done', a.out)
