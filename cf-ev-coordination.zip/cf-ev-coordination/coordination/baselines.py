"""
cf-ev-coordination / baselines.py - literature-derived coordination baseline for NS-EV.

jit<T>: just-in-time V2X clearing (distance/time-triggered emergency-vehicle warning, the principle of VANET
  EV warning systems, e.g. IEEE VNC 2009): a connected vehicle in the EV corridor is told to yield only when the EV
  will reach it within T seconds (or it is already holding the EV back), if its target position is free now and
  no other vehicle commanded in the same cycle moves into the same space (no weaving). It uses current states only:
  no prediction and no knowledge of driver traits. Arrival-time formula and the "blocking" test are identical to
  PACE's step (1), so jit<T> is PACE without its forecast-based steps (2) and (3).
  T is chosen on development scenes only (select_jit.py), never on test scenes.
"""
import numpy as np


def policy_jit(rp, fc=None, CL=None, P=None, t_trig=4.0):
    chosen = []
    for j in sorted(rp.corridor_cvs(CL.R_CTRL), key=lambda m: rp.s_i[m] - rp.se):
        gap = rp.s_i[j] - rp.se
        t_arr = max(gap - 15.0, 0.0) / max(rp.ev_v0 - rp.vnow[j], 1.0)
        blocking = gap < 40.0 and rp.ve < rp.ev_v0 - 2.0
        if t_arr > t_trig and not blocking: continue
        if not rp.target_free_now(j): continue
        dt = rp.d_i[j] + CL.yield_dir(rp.d_i[j], rp.side) * P.RESP['shift']
        if any(abs(dt - d2) < 2.0 and abs(rp.s_i[j] - s2) < 8.0 for s2, d2 in chosen): continue
        rp.command_yield(j); chosen.append((rp.s_i[j], dt))
