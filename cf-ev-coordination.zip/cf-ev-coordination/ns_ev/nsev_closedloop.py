"""
NS-EV stage 2: closed-loop emergency-vehicle coordination on reactive nuScenes replays.

The scene is replayed exactly as in nsev_pipeline.inject (same routes, response model, safety rules), but a
fraction rho of the recorded vehicles are connected vehicles (CVs). Every 0.5 s a coordination policy may command
CVs to yield. Commanded CVs react without human perception/reaction delay; all other vehicles (HDVs and
uncommanded CVs) follow the human response model. Identical random numbers are used for every policy, so results
are paired per replay.

Policies
  nocoord    : no commands (CVs behave as human drivers)
  reactive   : rule-based V2X broadcast - every CV in the EV corridor within 150 m is told to yield at once,
               if its target position is free *now* (current-state check only)
  pace       : prediction-conditioned, disruption-aware coordinator:
               (1) just-in-time: command a CV only when the EV will reach it within T_lead,
               (2) skip CVs forecast to leave the corridor on their own (p_clear >= 0.8),
               (3) command only if the forecast conflict risk at the yield position is <= theta_R,
               otherwise re-plan next cycle.  Forecasts: EVA-Net (K=6), Social-Attn, or constant velocity.
Usage
  python nsev_closedloop.py --dataroot $D --split val --rho 0.5 --out cl_val_rho0.5.jsonl \
         --eva nsevdr_s0_model_pace_K6.pkl --social nsevdr_s0_model_social_K6.pkl
"""
import argparse, math, json, time, os
import numpy as np
from nuscenes.nuscenes import NuScenes
import nsev_pipeline as P
from features import agent_features, cv_prior, F
from sim import idm

DT = P.DT
R_CTRL, T_LEAD, P_CLEAR, THETA_R = 200.0, 8.0, 0.8, 0.3


def yield_dir(d, side):
    """v8: yield away from the EV path; country rule only for vehicles near the EV centre line."""
    return float(np.sign(d)) if abs(d) >= 0.5 else float(side)


class Replay:
    def __init__(self, times, tracks, seed, rho, side, compliance, back, ev_v0=16.0):
        self.grid = np.arange(0, times[-1] + 1e-6, DT)
        self.ids = list(tracks); self.tr = {i: P.resample(tracks[i], self.grid) for i in self.ids}
        self.route, _ = P.build_route(self.tr, back=250.0)
        if self.route is None: self.ok = False; return
        self.ok = True; N = self.N = len(self.ids)
        self.lens = np.array([np.nanmax(tracks[i][:, 4]) for i in self.ids])
        rng = np.random.default_rng(seed)                 # human traits: identical for every policy
        u = rng.uniform(size=N); prompt = u < compliance; late = (~prompt) & (rng.uniform(size=N) < 0.75)
        self.comply = prompt | late; self.freeze = self.comply & (rng.uniform(size=N) < P.RESP['freeze_p'])
        self.dperc = np.where(late, rng.uniform(P.RESP['late_lo'], P.RESP['late_hi'], N), rng.uniform(P.RESP['dp_lo'], P.RESP['dp_hi'], N))
        self.react = np.clip(rng.lognormal(math.log(P.RESP['react_mu']), 0.45, N), 0.4, 6.0) + 0.8 * late
        self.is_cv = np.random.default_rng(seed + 99).uniform(size=N) < rho   # nested across rho
        self.side, self.ev_v0 = side, ev_v0
        self.taken = np.zeros(N, bool); self.aware_t = np.full(N, -1.0); self.kind = np.zeros(N, int)  # 1 follow 2 yield 3 freeze 4 commanded
        self.fs = np.zeros(N); self.fd = np.zeros(N); self.fv = np.zeros(N)
        self.d_from = np.zeros(N); self.d_to = np.zeros(N); self.lc_t = np.full(N, -1.0)
        self.age = np.zeros(N); self.se, self.ve = 250.0 - back, 12.0; self.s_start = None
        self.frames = []; self.k = 0; self.t = 0.0
        self.m = dict(collisions=0, spawn_conflict=False, ev_stops=0, ev_hb=0, commands=0, human_yields=0,
                      lost_m=0.0, disturbed=set(), min_ttc=99.0, conf_pairs=set(), near_pairs=set(), cmd_conf=0, coll_sim=0, coll_logged=0)
        self._stopped = False; self._hb = False; self.collided = set()
        self.s_i = np.full(N, np.nan); self.d_i = np.full(N, np.nan); self.aligned = np.zeros(N, bool)

    # ---- helpers used by policies
    def corridor_cvs(self, R):
        out = []
        for j in range(self.N):
            if not self.is_cv[j] or self.taken[j] or np.isnan(self.s_i[j]) or not self.aligned[j]: continue
            g = self.s_i[j] - self.se
            if 0 < g < R and abs(self.d_i[j]) < 2.6: out.append(j)
        return out

    def command_yield(self, j):
        self.taken[j] = True; self.kind[j] = 4; self.m['commands'] += 1; self.m['disturbed'].add(j)
        self.fs[j], self.fd[j] = self.s_i[j], self.d_i[j]; self.fv[j] = self.vnow[j]
        self.d_from[j] = self.fd[j]; self.d_to[j] = self.fd[j] + yield_dir(self.fd[j], self.side) * P.RESP['shift']; self.lc_t[j] = self.t

    def target_free_now(self, j):
        dt_ = self.d_i[j] + yield_dir(self.d_i[j], self.side) * P.RESP['shift']
        for m in range(self.N):
            if m == j or np.isnan(self.s_i[m]): continue
            if abs(self.d_i[m] - dt_) < 2.0 and abs(self.s_i[m] - self.s_i[j]) < 8.0: return False
        return True

    # ---- one 0.1-s step
    def step(self):
        k, t, N = self.k, self.grid[self.k], self.N
        pos = np.array([self.tr[i][k, :2] for i in self.ids]); vel = np.array([self.tr[i][k, 3] for i in self.ids])
        present = ~np.isnan(pos[:, 0])
        self.age = np.where(present | self.taken, self.age + DT, 0.0) if k else np.where(present, 99.0, 0.0)
        s_i = np.full(N, np.nan); d_i = np.full(N, np.nan); aligned = np.zeros(N, bool)
        if present.any():
            s_p, d_p, hr = self.route.project(pos[present]); yaw = np.array([self.tr[i][k, 2] for i in self.ids])[present]
            s_i[present] = s_p; d_i[present] = d_p; aligned[present] = np.cos(yaw - hr) > 0.7
        vnow = np.where(self.taken, self.fv, np.nan_to_num(vel))
        se, ve = self.se, self.ve
        for j in np.where(self.taken)[0]:
            lead_gap, lead_v = 1e4, 0.0
            for m in range(N):
                if m == j or np.isnan(s_i[m]): continue
                sm = self.fs[m] if self.taken[m] else s_i[m]; dm = self.fd[m] if self.taken[m] else d_i[m]
                if abs(dm - self.fd[j]) < 2.0 and 0 < sm - self.fs[j] < lead_gap: lead_gap, lead_v = sm - self.fs[j] - self.lens[m], vnow[m]
            if abs(self.fd[j]) < 2.6 and 0 < se - self.fs[j] < lead_gap + 6.5: lead_gap, lead_v = se - self.fs[j] - 6.5, ve
            vlog = vel[j] if not np.isnan(vel[j]) else self.fv[j]
            if self.kind[j] == 3 and se < self.fs[j]: a = -3.0 if self.fv[j] > 0.5 else 0.0
            else:
                ev_behind = se < self.fs[j]
                a = float(idm(self.fv[j], max(vlog, 3.0), max(lead_gap, 0.1), self.fv[j] - lead_v, 1.4, 1.3, 2.0, 2.0))
                if ev_behind:   # pulling over: slow to 50-60% speed with comfortable deceleration only (v7 fix)
                    v_t = max((0.6 if self.kind[j] == 4 else 0.5) * vlog, 3.0)
                    a = min(a, float(np.clip(0.8 * (v_t - self.fv[j]), -2.0, 0.5)))
            self.fv[j] = max(0.0, self.fv[j] + np.clip(a, -8, 3) * DT); self.fs[j] += self.fv[j] * DT
            if not np.isnan(vel[j]): self.m['lost_m'] += max(0.0, vel[j] - self.fv[j]) * DT    # vs. the real log
            if self.lc_t[j] >= 0:
                dur = 2.5 if self.kind[j] == 4 else 3.0
                pr = min(1.0, (t - self.lc_t[j]) / dur); self.fd[j] = self.d_from[j] + (self.d_to[j] - self.d_from[j]) * (1 - math.cos(math.pi * pr)) / 2
            s_i[j], d_i[j], aligned[j] = self.fs[j], self.fd[j], True
        self.s_i, self.d_i, self.aligned, self.vnow = s_i, d_i, aligned, np.where(self.taken, self.fv, np.nan_to_num(vel))
        # civilian conflicts caused by yielding manoeuvres: a yielding vehicle overlaps (conflict) or comes within
        # 1 m longitudinally (near miss) of another vehicle in the lateral space it moves into
        for j in np.where(self.taken & ((self.kind == 2) | (self.kind == 4)) & (self.lc_t >= 0))[0]:
            for m in range(N):
                if m == j or np.isnan(s_i[m]) or self.age[m] < 1.0: continue
                if abs(d_i[m] - d_i[j]) >= 1.9: continue
                ds = abs(s_i[m] - s_i[j]) - 0.5 * (self.lens[m] + self.lens[j])
                key = (min(j, m), max(j, m))
                if ds < 0 and key not in self.m['conf_pairs']:
                    self.m['conf_pairs'].add(key)
                    if self.kind[j] == 4: self.m['cmd_conf'] += 1          # conflict created by a commanded CV
                elif ds < 1.0 and key not in self.m['near_pairs']: self.m['near_pairs'].add(key)
        # human perception / reaction (HDVs and uncommanded CVs)
        for j in np.where(~self.taken & ~np.isnan(s_i) & aligned)[0]:
            gap = s_i[j] - se
            if -40 < gap < 0 and abs(d_i[j]) < 2.6:
                self.taken[j] = True; self.kind[j] = 1; self.fs[j], self.fd[j], self.fv[j] = s_i[j], d_i[j], self.vnow[j]; self.m['disturbed'].add(j); continue
            if self.comply[j] and 0 < gap < self.dperc[j] and abs(d_i[j]) < 6.0:
                if self.aware_t[j] < 0: self.aware_t[j] = t
                if t - self.aware_t[j] >= self.react[j] and abs(d_i[j]) < 2.6:
                    self.taken[j] = True; self.m['human_yields'] += 1; self.m['disturbed'].add(j)
                    self.fs[j], self.fd[j], self.fv[j] = s_i[j], d_i[j], self.vnow[j]
                    if self.freeze[j]: self.kind[j] = 3
                    else: self.kind[j] = 2; self.d_from[j] = self.fd[j]; self.d_to[j] = self.fd[j] + yield_dir(self.fd[j], self.side) * P.RESP['shift']; self.lc_t[j] = t
        if k == 0:
            occ = (~np.isnan(s_i)) & aligned & (np.abs(np.nan_to_num(d_i, nan=99)) < 2.6)
            if occ.any() and np.nanmin(s_i[occ]) < se + 15: se = max(0.0, float(np.nanmin(s_i[occ])) - 15.0)
            self.s_start = se
        lead_gap, lead_v = 1e4, 0.0
        for j in range(N):
            if np.isnan(s_i[j]) or abs(d_i[j]) >= 2.6 or self.age[j] < 1.0: continue
            g = s_i[j] - se - (self.lens[j] if aligned[j] else 2.5)
            if -self.lens[j] < s_i[j] - se and g < lead_gap:
                lead_gap, lead_v = g, (self.vnow[j] if aligned[j] else 0.0)
        if lead_gap < 1e3 and ve > lead_v: self.m['min_ttc'] = min(self.m['min_ttc'], max(lead_gap, 0.0) / (ve - lead_v))
        for j in range(N):
            if np.isnan(s_i[j]): continue
            ov = abs(d_i[j]) < 2.05 and abs(s_i[j] - self.lens[j] / 2 - (se - 3.25)) < (self.lens[j] + 6.5) / 2
            if ov and self.age[j] < 1.0: self.m['spawn_conflict'] = True
            elif ov and j not in self.collided:
                self.collided.add(j); self.m['collisions'] += 1
                if self.taken[j]: self.m['coll_sim'] += 1        # vehicle under simulation control (commanded / responding)
                else: self.m['coll_logged'] += 1                 # non-reactive logged vehicle (replay limitation)
        ae = float(np.clip(idm(ve, self.ev_v0, max(lead_gap, 0.1), ve - lead_v, 0.6, 2.5, 3.0, 2.5), -8, 3))
        if ae < -4 and not self._hb: self.m['ev_hb'] += 1
        self._hb = ae < -4
        ve = max(0.0, ve + ae * DT); se += ve * DT
        if ve < 1.0 and not self._stopped: self.m['ev_stops'] += 1; self._stopped = True
        if ve > 3.0: self._stopped = False
        self.se, self.ve = se, ve
        if k % 5 == 0:
            fr = np.full((N + 1, 3), 1e6); ok = ~np.isnan(s_i)
            fr[:N][ok] = np.c_[s_i[ok], d_i[ok], self.vnow[ok]]; fr[N] = [se, 0.0, ve]; self.frames.append(fr)
        self.k += 1; self.t = t

    def done(self): return self.k >= len(self.grid)

    def result(self):
        T = self.grid[-1]; prog = self.se - self.s_start
        return dict(ev_progress=round(prog, 2), ev_speed=round(prog / T, 3), ev_delay=round(T - prog / self.ev_v0, 3),
                    ev_stops=self.m['ev_stops'], ev_hb=self.m['ev_hb'], collisions=self.m['collisions'], coll_sim=self.m['coll_sim'], coll_logged=self.m['coll_logged'],
                    spawn_conflict=self.m['spawn_conflict'], commands=self.m['commands'], human_yields=self.m['human_yields'],
                    disturbed=len(self.m['disturbed']), civ_conflicts=len(self.m['conf_pairs']), civ_near=len(self.m['near_pairs']), cmd_conflicts=self.m['cmd_conf'], lost_m=round(self.m['lost_m'], 2), min_ttc=round(min(self.m['min_ttc'], 10.0), 3))


# ------------------------------------------------------------------ forecasters (Frenet frame, relative to agent)
class Forecaster:
    def __init__(self, model=None, ev_agnostic=False): self.m, self.ag = model, ev_agnostic
    def __call__(self, rp, ids):
        """returns {j: list of (prob, traj[F,2] absolute s,d)}"""
        out = {}
        if not ids: return out
        if self.m is None or len(rp.frames) < 4:
            for j in ids:
                tt = 0.5 * np.arange(1, F + 1); out[j] = [(1.0, np.c_[rp.s_i[j] + rp.vnow[j] * tt, np.full(F, rp.d_i[j])])]
            return out
        fr = rp.frames[-4:]; types = np.zeros(rp.N + 1, int); types[rp.N] = 2; lanes = np.ones(rp.N + 1, int)
        ok = [j for j in ids if all(f[j, 0] < 1e5 for f in fr)]
        for j in set(ids) - set(ok):
            tt = 0.5 * np.arange(1, F + 1); out[j] = [(1.0, np.c_[rp.s_i[j] + rp.vnow[j] * tt, np.full(F, rp.d_i[j])])]
        if not ok: return out
        X = [agent_features(fr, types, lanes, j, rp.N, self.ag) for j in ok]
        tr, pr = self.m.predict(np.array([x[0] for x in X]), np.array([x[1] for x in X]), np.array([x[2] for x in X]),
                                np.array([x[3] for x in X]), np.array([cv_prior(fr, j) for j in ok]))
        for n, j in enumerate(ok):
            x0, y0 = fr[-1][j, 0], fr[-1][j, 1]
            out[j] = [(float(pr[n, q]), np.c_[x0 + tr[n, q, :, 0] * 10.0, y0 + tr[n, q, :, 1] * P.LANE_W]) for q in range(tr.shape[1]) if pr[n, q] > 0.02]
            z = sum(p for p, _ in out[j]); out[j] = [(p / z, tr_) for p, tr_ in out[j]]
        return out


def policy_reactive(rp, fc=None):
    for j in rp.corridor_cvs(150.0):
        if rp.target_free_now(j): rp.command_yield(j)


def policy_pace(rp, fc):
    cands = rp.corridor_cvs(R_CTRL)
    if not cands: return
    near = [m for m in range(rp.N) if not np.isnan(rp.s_i[m]) and -20 < rp.s_i[m] - rp.se < R_CTRL + 30]
    pred = fc(rp, near)
    for j in cands:
        gap = rp.s_i[j] - rp.se
        t_arr = max(gap - 15.0, 0.0) / max(rp.ev_v0 - rp.vnow[j], 1.0)   # time until j would constrain an unobstructed EV
        blocking = gap < 40.0 and rp.ve < rp.ev_v0 - 2.0                  # j is already holding the EV back
        if t_arr > T_LEAD and not blocking: continue                           # (1) just in time
        ti = int(np.clip(math.ceil(t_arr / 0.5) - 1, 0, F - 1))
        p_clear = sum(p for p, tr in pred.get(j, []) if abs(tr[ti, 1]) >= 2.6)
        if p_clear >= P_CLEAR: continue                                         # (2) will clear by itself
        d_t = rp.d_i[j] + yield_dir(rp.d_i[j], rp.side) * P.RESP['shift']; risk = 0.0                # (3) forecast conflict risk
        sj = rp.s_i[j] + 0.6 * rp.vnow[j] * 0.5 * np.arange(1, F + 1)
        for m, modes in pred.items():
            if m == j: continue
            for p, tr in modes:
                if np.any((np.abs(tr[:, 1] - d_t) < 2.0) & (np.abs(tr[:, 0] - sj) < 6.0)): risk += p
        if risk <= THETA_R: rp.command_yield(j)


def run_replay(times, tracks, seed, rho, side, compliance, back, policy, fc):
    rp = Replay(times, tracks, seed, rho, side, compliance, back)
    if not rp.ok: return None
    t0 = time.perf_counter(); lat = []
    while not rp.done():
        if policy is not None and rp.k % 5 == 0 and rp.k > 0:
            a = time.perf_counter(); policy(rp, fc); lat.append(time.perf_counter() - a)
        rp.step()
    r = rp.result(); r['plan_ms'] = round(1000 * float(np.median(lat)), 2) if lat else 0.0; r['wall_s'] = round(time.perf_counter() - t0, 2)
    return r


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataroot', required=True); ap.add_argument('--version', default='v1.0-trainval')
    ap.add_argument('--split', default='val'); ap.add_argument('--rho', type=float, default=0.5)
    ap.add_argument('--injections', type=int, default=2); ap.add_argument('--out', required=True)
    ap.add_argument('--eva', default='nsevdr_s0_model_pace_K6.pkl'); ap.add_argument('--social', default='nsevdr_s0_model_social_K6.pkl')
    ap.add_argument('--compliance', type=float, default=0.7); ap.add_argument('--max_scenes', type=int, default=0)
    ap.add_argument('--t_lead', type=float, default=T_LEAD); ap.add_argument('--theta_r', type=float, default=THETA_R)
    ap.add_argument('--policies', default='nocoord,reactive,pace_cv,pace_social,pace_eva')
    a = ap.parse_args(); T_LEAD, THETA_R = a.t_lead, a.theta_r
    from model import Predictor
    POL = {'nocoord': (None, None), 'reactive': (policy_reactive, None),
           'pace_cv': (policy_pace, Forecaster(None)),
           'pace_social': (policy_pace, Forecaster(Predictor.load(a.social), ev_agnostic=True)),
           'pace_eva': (policy_pace, Forecaster(Predictor.load(a.eva)))}
    POL = {k: v for k, v in POL.items() if k in a.policies.split(',')}
    nusc = NuScenes(a.version, a.dataroot, verbose=False)
    if a.split == 'all': scenes = nusc.scene
    else:
        from nuscenes.utils.splits import create_splits_scenes
        sp = create_splits_scenes()
        if a.split == 'train_holdout': names = set(sorted(sp['train'])[::10])      # development scenes (never test)
        else: names = set(sp[a.split])
        scenes = [s for s in nusc.scene if s['name'] in names]
    if a.max_scenes: scenes = scenes[:a.max_scenes]
    done = set()
    if os.path.exists(a.out):
        for l in open(a.out): r = json.loads(l); done.add((r['scene'], r['inj'], r['policy']))
    t0 = time.time()
    for si, sc in enumerate(scenes):
        loc = nusc.get('log', sc['log_token'])['location']; side = +1 if loc.startswith('singapore') else -1
        times, tracks = P.load_scene_tracks(nusc, sc)
        for inj in range(a.injections):
            seed = 7919 * si + inj; back = np.random.default_rng(seed + 5).uniform(40, 100)
            base = run_replay(times, tracks, seed, a.rho, side, a.compliance, back, None, None)
            if base is None or base['spawn_conflict'] or base['collisions'] > 0: continue   # pre-registered validity filter
            for name, (pol, fc) in POL.items():
                if (sc['name'], inj, name) in done: continue
                r = base if name == 'nocoord' else run_replay(times, tracks, seed, a.rho, side, a.compliance, back, pol, fc)
                r = dict(r, scene=sc['name'], location=loc, inj=inj, policy=name, rho=a.rho, compliance=a.compliance)
                with open(a.out, 'a') as f: f.write(json.dumps(r) + '\n')
        if si % 10 == 0: print(f'{si}/{len(scenes)} scenes, {time.time() - t0:.0f}s', flush=True)
    print('done', a.out)
