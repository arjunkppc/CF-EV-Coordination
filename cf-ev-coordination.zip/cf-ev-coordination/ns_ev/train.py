import numpy as np, sys, time
from model import Predictor
def load(f, kind):
    Z = dict(np.load(f))
    D = {k: Z[k].astype(np.float64) for k in ['hist','ev','nb','mask','prior','y']}
    if kind == 'social':
        D['nb'] = Z['nb_ag'].astype(np.float64); D['mask'] = Z['mask_ag'].astype(np.float64); D['ev'] = D['ev'] * 0
    if kind == 'mlp': D['ev'] = D['ev'] * 0
    return D
if __name__ == "__main__":
  kind, K, ep = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
  tr_f = sys.argv[4] if len(sys.argv) > 4 else 'data_train.npz'; va_f = sys.argv[5] if len(sys.argv) > 5 else 'data_val.npz'
  D = load(tr_f, kind); V = load(va_f, kind)
  seed = int(sys.argv[7]) if len(sys.argv) > 7 else 0
  m = Predictor(kind, K, seed=seed); t0 = time.time()
  m.fit(D, V, epochs=ep, log=True)
  m.save(sys.argv[6] if len(sys.argv) > 6 else f'model_{kind}_K{K}.pkl'); print('done', time.time() - t0)
