"""
NS-EV: inject a simulated emergency vehicle (EV) into real nuScenes scenes with reactive log replay.

Every vehicle follows its recorded nuScenes trajectory until it perceives the EV (range d_p, reaction delay tau);
compliant drivers are then taken over by the driver-response model and yield laterally or brake; all other
vehicles stay on their logged trajectories. Output samples use the PACE-EV feature format (features.py), expressed
in the Frenet frame of the EV route (x = arc length s, y = lateral offset d), so EVA-Net trains unchanged.

Usage:
  python nsev_pipeline.py --dataroot /data/nuscenes --version v1.0-trainval --split train --out nsev_train.npz
Splits: train / val use nuScenes' official scene splits (val is held out); 'all' uses every scene (for mini tests).
"""
import argparse, math, json, time
import numpy as np
from nuscenes.nuscenes import NuScenes
from features import agent_features, cv_prior, future_target, H, F
from sim import idm

DT, HZ_LOG = 0.1, 2.0
# driver-response parameters (defaults = PACE-EV model); overridable from the command line for stress tests
RESP = dict(dp_lo=60.0, dp_hi=140.0, late_lo=18.0, late_hi=35.0, react_mu=1.4, freeze_p=0.18, shift=3.2)
LANE_W = 3.5


# ------------------------------------------------------------------ nuScenes loading
def load_scene_tracks(nusc, scene):
    """Return keyframe times (s) and dict track_id -> (times, xy[n,2], yaw[n]) for vehicles + ego."""
    samples, tok = [], scene['first_sample_token']
    while tok:
        s = nusc.get('sample', tok); samples.append(s); tok = s['next']
    t0 = samples[0]['timestamp'] / 1e6
    times = np.array([s['timestamp'] / 1e6 - t0 for s in samples])
    tracks = {}
    for k, s in enumerate(samples):
        for at in s['anns']:
            a = nusc.get('sample_annotation', at)
            if not a['category_name'].startswith('vehicle.') or 'emergency' in a['category_name']:
                continue
            if a['category_name'] in ('vehicle.bicycle', 'vehicle.motorcycle'):
                continue
            q = a['rotation']; yaw = math.atan2(2 * (q[0] * q[3] + q[1] * q[2]), 1 - 2 * (q[2] ** 2 + q[3] ** 2))
            tracks.setdefault(a['instance_token'], []).append((times[k], a['translation'][0], a['translation'][1], yaw, a['size'][1]))
        sd = nusc.get('sample_data', s['data']['LIDAR_TOP']); ep = nusc.get('ego_pose', sd['ego_pose_token'])
        q = ep['rotation']; yaw = math.atan2(2 * (q[0] * q[3] + q[1] * q[2]), 1 - 2 * (q[2] ** 2 + q[3] ** 2))
        tracks.setdefault('ego', []).append((times[k], ep['translation'][0], ep['translation'][1], yaw, 4.6))
    out = {}
    for tid, rows in tracks.items():
        r = np.array(sorted(rows))
        if len(r) >= 2: out[tid] = r
    return times, out


def resample(track, grid):
    """Linear interpolation of a (t, x, y, yaw, len) track onto a time grid; NaN outside the observed span."""
    t = track[:, 0]; out = np.full((len(grid), 4), np.nan)
    m = (grid >= t[0]) & (grid <= t[-1])
    out[m, 0] = np.interp(grid[m], t, track[:, 1]); out[m, 1] = np.interp(grid[m], t, track[:, 2])
    out[m, 2] = np.interp(grid[m], t, np.unwrap(track[:, 3]))
    if m.sum() >= 2:
        v = np.gradient(out[m, :2], DT, axis=0); out[m, 3] = np.hypot(v[:, 0], v[:, 1])
    elif m.any(): out[m, 3] = 0.0
    return out


# ------------------------------------------------------------------ EV route in a Frenet frame
class Route:
    def __init__(self, pts):
        d = np.r_[0, np.cumsum(np.hypot(*np.diff(pts, axis=0).T))]
        self.s_all = np.arange(0, d[-1], 0.5)
        self.p = np.c_[np.interp(self.s_all, d, pts[:, 0]), np.interp(self.s_all, d, pts[:, 1])]
        tg = np.gradient(self.p, axis=0); tg /= np.linalg.norm(tg, axis=1, keepdims=True) + 1e-9
        self.t = tg; self.n = np.c_[-tg[:, 1], tg[:, 0]]            # left normal
        self.length = self.s_all[-1]

    def project(self, xy):
        """xy [m,2] -> (s, d, heading of route at s)."""
        dd = ((xy[:, None, :] - self.p[None]) ** 2).sum(-1); k = dd.argmin(1)
        rel = xy - self.p[k]
        s = self.s_all[k] + (rel * self.t[k]).sum(1); d = (rel * self.n[k]).sum(1)
        return s, d, np.arctan2(self.t[k, 1], self.t[k, 0])

    def to_xy(self, s, d):
        k = np.clip(np.round(np.asarray(s) / 0.5).astype(int), 0, len(self.s_all) - 1)
        return self.p[k] + np.asarray(d)[..., None] * self.n[k]


def build_route(tr_grid, back=80.0, min_len=60.0):
    """EV route = path of a moving recorded vehicle (follows a real lane), extended backwards along its initial heading."""
    best, best_len = None, 0.0
    for tid, a in tr_grid.items():
        ok = ~np.isnan(a[:, 0]); p = a[ok, :2]
        if len(p) < 20: continue
        L = np.hypot(*np.diff(p, axis=0).T).sum()
        if L > best_len and np.nanmean(a[ok, 3]) > 2.0: best, best_len = tid, L
    if best is None or best_len < min_len: return None, None
    a = tr_grid[best]; p = a[~np.isnan(a[:, 0]), :2]
    h = p[min(5, len(p) - 1)] - p[0]; h /= np.linalg.norm(h) + 1e-9
    back_pts = p[0] - np.outer(np.linspace(back, 0.5, int(back / 0.5)), h)
    return Route(np.r_[back_pts, p]), best


# ------------------------------------------------------------------ reactive log replay
def inject(times, tracks, rng, compliance=0.7, side=-1, ev_v0=16.0, back=80.0):
    """side = -1: yield to the right (Boston), +1: yield to the left (Singapore)."""
    grid = np.arange(0, times[-1] + 1e-6, DT)
    ids = list(tracks); tr = {i: resample(tracks[i], grid) for i in ids}
    route, host = build_route(tr, back=250.0)       # long run-up; the EV start is placed below
    if route is None: return None
    N = len(ids); lens = np.array([np.nanmax(tracks[i][:, 4]) for i in ids])
    # driver-response classes (same model as PACE-EV, Section III-B)
    u = rng.uniform(size=N); prompt = u < compliance; late = (~prompt) & (rng.uniform(size=N) < 0.75)
    comply = prompt | late; freeze = comply & (rng.uniform(size=N) < RESP['freeze_p'])
    dperc = np.where(late, rng.uniform(RESP['late_lo'], RESP['late_hi'], N), rng.uniform(RESP['dp_lo'], RESP['dp_hi'], N))
    react = np.clip(rng.lognormal(math.log(RESP['react_mu']), 0.45, N), 0.4, 6.0) + 0.8 * late
    driver = np.where(prompt, 0, np.where(late, 1, 2))
    # state
    take_t = np.full(N, np.inf)      # time at which a driver reacted to the EV (yield or panic brake)
    taken = np.zeros(N, bool); aware_t = np.full(N, -1.0); fs = np.zeros(N); fd = np.zeros(N); fv = np.zeros(N)
    d_from = np.zeros(N); d_to = np.zeros(N); lc_t = np.full(N, -1.0)
    age = np.zeros(N); collided = set(); spawn_conflict = False; coll_info = []
    se, ve = 250.0 - back, 12.0; ev_done = None; frames = []; n_take = 0; min_gap = 99.0; ev_stops = 0; stopped = False
    for k, t in enumerate(grid):
        pos = np.array([tr[i][k, :2] for i in ids]); vel = np.array([tr[i][k, 3] for i in ids])
        present = ~np.isnan(pos[:, 0])
        age = np.where(present | taken, age + DT, 0.0) if k else np.where(present, 99.0, 0.0)
        s_i = np.full(N, np.nan); d_i = np.full(N, np.nan); aligned = np.zeros(N, bool)
        if present.any():
            s_p, d_p, hr = route.project(pos[present])
            yaw = np.array([tr[i][k, 2] for i in ids])[present]
            s_i[present] = s_p; d_i[present] = d_p; aligned[present] = np.cos(yaw - hr) > 0.7
        # taken-over agents evolve in the Frenet frame
        for j in np.where(taken)[0]:
            lead_gap = 1e4; lead_v = 0.0
            for m in range(N):
                if m == j or np.isnan(s_i[m]): continue
                if abs(d_i[m] - fd[j]) < 2.0 and 0 < s_i[m] - fs[j] < lead_gap: lead_gap, lead_v = s_i[m] - fs[j] - lens[m], vel[m]
            if abs(fd[j]) < 2.6 and 0 < se - fs[j] < lead_gap + 6.5:      # the EV itself can be the leader
                lead_gap, lead_v = se - fs[j] - 6.5, ve
            if freeze[j] and se < fs[j]: a = -3.0 if fv[j] > 0.5 else 0.0
            else:
                vref = vel[j] if not np.isnan(vel[j]) else 5.0
                a = float(idm(fv[j], max(vref, 3.0), max(lead_gap, 0.1), fv[j] - lead_v, 1.4, 1.3, 2.0, 2.0))
                if se < fs[j]:   # pulling over for the EV: slow to 50% speed with comfortable deceleration only
                    a = min(a, float(np.clip(0.8 * (max(0.5 * vref, 3.0) - fv[j]), -2.0, 0.5)))
            fv[j] = max(0.0, fv[j] + np.clip(a, -8, 3) * DT); fs[j] += fv[j] * DT
            if lc_t[j] >= 0:
                pr = min(1.0, (t - lc_t[j]) / 3.0); fd[j] = d_from[j] + (d_to[j] - d_from[j]) * (1 - math.cos(math.pi * pr)) / 2
            s_i[j], d_i[j], aligned[j] = fs[j], fd[j], True
        # perception, reaction and takeover
        for j in np.where(~taken & ~np.isnan(s_i) & aligned)[0]:
            gap = s_i[j] - se
            if -40 < gap < 0 and abs(d_i[j]) < 2.6:      # logged followers cannot drive through the EV: take over as car-followers
                taken[j] = True; fs[j], fd[j], fv[j] = s_i[j], d_i[j], (vel[j] if not np.isnan(vel[j]) else 0.0)
                continue
            if comply[j] and 0 < gap < dperc[j] and abs(d_i[j]) < 6.0 and ev_done is None:
                if aware_t[j] < 0: aware_t[j] = t
                if t - aware_t[j] >= react[j] and abs(d_i[j]) < 2.6:
                    taken[j] = True; n_take += 1; take_t[j] = t; fs[j], fd[j], fv[j] = s_i[j], d_i[j], (vel[j] if not np.isnan(vel[j]) else 0.0)
                    if not freeze[j]: d_from[j] = fd[j]; d_to[j] = fd[j] + (np.sign(fd[j]) if abs(fd[j]) >= 0.5 else side) * RESP['shift']; lc_t[j] = t
        if k == 0:   # never spawn the EV inside a queue: start 15 m behind the last corridor vehicle
            occ = (~np.isnan(s_i)) & aligned & (np.abs(np.nan_to_num(d_i, nan=99)) < 2.6)
            if occ.any() and np.nanmin(s_i[occ]) < se + 15: se = max(0.0, float(np.nanmin(s_i[occ])) - 15.0)
            s_start = se
        # EV: IDM behind nearest corridor occupant (logged vehicles do not react, so the EV must brake for them)
        lead_gap, lead_v = 1e4, 0.0
        for j in range(N):
            if np.isnan(s_i[j]) or abs(d_i[j]) >= 2.6: continue
            if age[j] < 1.0: continue          # track just (re)appeared at sensor range: not a physical cut-in
            g = s_i[j] - se - (lens[j] if aligned[j] else 2.5)
            if -lens[j] < s_i[j] - se and g < lead_gap:
                # aligned traffic moves with the EV; crossing/oncoming vehicles are treated as stationary obstacles
                lead_gap, lead_v = g, ((fv[j] if taken[j] else vel[j]) if aligned[j] else 0.0)
        min_gap = min(min_gap, max(lead_gap, 0.0))
        for j in range(N):   # physical overlap of EV box (6.5 x 2.2 m) with a vehicle box (~1.9 m wide)
            if np.isnan(s_i[j]): continue
            ov = abs(d_i[j]) < 2.05 and abs(s_i[j] - lens[j] / 2 - (se - 3.25)) < (lens[j] + 6.5) / 2
            if ov and age[j] < 1.0: spawn_conflict = True     # a logged track entered sensor range inside the EV
            if age[j] < 1.0: continue
            if abs(d_i[j]) < 2.05 and abs(s_i[j] - lens[j] / 2 - (se - 3.25)) < (lens[j] + 6.5) / 2 and j not in collided:
                collided.add(j)
                coll_info.append(dict(t=round(float(t), 1), aligned=bool(aligned[j]), taken=bool(taken[j]),
                                      d=round(float(d_i[j]), 2), ds=round(float(s_i[j] - se), 2),
                                      v_other=round(float(np.nan_to_num(vel[j])), 2), v_ev=round(float(ve), 2)))
        ae = float(idm(ve, ev_v0, max(lead_gap, 0.1), ve - lead_v, 0.6, 2.5, 3.0, 2.5))
        ve = max(0.0, ve + np.clip(ae, -8, 3) * DT); se += ve * DT
        if ve < 1.0 and not stopped: ev_stops += 1; stopped = True
        if ve > 3.0: stopped = False
        if ev_done is None and se >= route.length: ev_done = t
        if k % int(round(1 / (HZ_LOG * DT))) == 0:
            v_now = np.where(taken, fv, vel)
            fr = np.full((N + 1, 3), 1e6); ok = ~np.isnan(s_i)
            fr[:N][ok] = np.c_[s_i[ok], d_i[ok], v_now[ok]]; fr[N] = [se, 0.0, ve]
            frames.append(fr)
    return dict(take_t=take_t, ev_mean_speed=(se - s_start) / grid[-1], ev_progress=se - s_start, frames=frames, N=N, driver=driver, freeze=freeze, host=host, route_len=route.length,
                ev_time=ev_done, ev_stops=ev_stops, takeovers=n_take, min_gap=min_gap, collisions=len(collided), coll_info=coll_info, spawn_conflict=spawn_conflict)


def extract_samples(res, rng, p_ev=0.6, p_bg=0.05):
    take_t = res['take_t']
    fr = res['frames']; N = res['N']; e = N; rows = []
    types = np.zeros(N + 1, int); types[e] = 2; lanes = np.ones(N + 1, int)      # urban: no lane-edge flags
    for t in range(H - 1, len(fr) - F):
        win = fr[t - H + 1:t + F + 1]; past, fut, cur = win[:H], win[H:], win[H - 1]
        for i in range(N):
            if np.any(np.array([w[i, 0] for w in win]) > 1e5): continue        # needs full 5-s window
            if abs(cur[i, 1]) > 8: continue                                    # keep agents near the EV route
            near = -10 < cur[i, 0] - cur[e, 0] < 220
            reacted = take_t[i] <= (t + F) / HZ_LOG          # reaction happens before the end of the 3-s future
            if not reacted and rng.uniform() > (p_ev if near else p_bg): continue
            h, ev, nb, mk = agent_features(past, types, lanes, i, e)
            _, _, nb2, mk2 = agent_features(past, types, lanes, i, e, ev_agnostic=True)
            rows.append((h, ev, nb, mk, nb2, mk2, cv_prior(past, i), future_target(fut, cur, i), int(near),
                         int(res['driver'][i]), int(res['freeze'][i]), int(reacted)))
    return rows


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataroot', required=True); ap.add_argument('--version', default='v1.0-trainval')
    ap.add_argument('--split', default='train'); ap.add_argument('--out', default='nsev_train.npz')
    ap.add_argument('--injections', type=int, default=3, help='EV injections per scene (different routes/seeds)')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--randomize', action='store_true', help='sample response parameters per replay (domain randomisation)')
    for k_, v_ in RESP.items(): ap.add_argument('--' + k_, type=float, default=v_)
    a = ap.parse_args()
    for k_ in RESP: RESP[k_] = getattr(a, k_)
    print('response parameters:', RESP, flush=True)
    nusc = NuScenes(a.version, a.dataroot, verbose=False)
    if a.split == 'all': scenes = nusc.scene
    else:
        from nuscenes.utils.splits import create_splits_scenes
        sp = create_splits_scenes()
        if a.split in ('train_fit', 'train_holdout'):          # 90/10 split of nuScenes train for fitting / validation
            tr = sorted(sp['train']); hold = set(tr[::10])
            names = hold if a.split == 'train_holdout' else set(tr) - hold
        else: names = set(sp[a.split])
        scenes = [s for s in nusc.scene if s['name'] in names]
    dr = np.random.default_rng(a.seed + 1000)
    rng = np.random.default_rng(a.seed); rows, log = [], []; t0 = time.time()
    for si, sc in enumerate(scenes):
        loc = nusc.get('log', sc['log_token'])['location']
        side = +1 if loc.startswith('singapore') else -1
        times, tracks = load_scene_tracks(nusc, sc)
        for inj in range(a.injections):
            c = [0.5, 0.7, 0.9][(si + inj) % 3]
            if a.randomize:   # per-replay response model drawn from wide ranges
                RESP.update(dp_lo=dr.uniform(40, 80), react_mu=dr.uniform(1.0, 2.4), freeze_p=dr.uniform(0.05, 0.35), shift=dr.uniform(2.0, 3.8))
                RESP['dp_hi'] = RESP['dp_lo'] + dr.uniform(40, 80)
            res = inject(times, tracks, rng, compliance=c, side=side, back=rng.uniform(40, 100))
            if res is None: continue
            if res['spawn_conflict']:            # infeasible replay (log object appears inside the EV): discard
                log.append(dict(scene=sc['name'], location=loc, discarded='spawn_conflict')); continue
            if res['collisions'] > 0:          # logged (non-reactive) vehicle drove into the EV: replay infeasible
                log.append(dict(scene=sc['name'], location=loc, discarded='log_conflict', coll_info=res['coll_info'])); continue
            r = extract_samples(res, rng); rows += r
            log.append(dict(resp={k_: round(v_, 3) for k_, v_ in RESP.items()}, scene=sc['name'], location=loc, compliance=c, route_len=round(res['route_len'], 1),
                            ev_time=res['ev_time'], ev_mean_speed=round(res['ev_mean_speed'], 2), ev_stops=res['ev_stops'], takeovers=res['takeovers'],
                            min_gap=round(float(res['min_gap']), 2), collisions=res['collisions'], coll_info=res['coll_info'], samples=len(r)))
        if si % 50 == 0: print(f'{si}/{len(scenes)} scenes, {len(rows)} samples, {time.time() - t0:.0f}s', flush=True)
    names = ['hist', 'ev', 'nb', 'mask', 'nb_ag', 'mask_ag', 'prior', 'y', 'near', 'driver', 'freeze', 'reacted']
    np.savez_compressed(a.out, **{n: np.array(c) for n, c in zip(names, zip(*rows))})
    json.dump(log, open(a.out.replace('.npz', '_log.json'), 'w'), indent=1)
    print(f'saved {a.out}: {len(rows)} samples from {len(log)} injections over {len(scenes)} scenes')
