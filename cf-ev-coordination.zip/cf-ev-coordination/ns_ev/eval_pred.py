import numpy as np, json, time, sys
TEST = sys.argv[1] if len(sys.argv) > 1 else 'data_test.npz'
PFX = sys.argv[2] if len(sys.argv) > 2 else ''
OUT = sys.argv[3] if len(sys.argv) > 3 else 'res_pred.json'
from model import Predictor
from train import load
SC = np.array([10.0, 3.5])
def auc(s, y):
    o = np.argsort(s); r = np.empty(len(s)); r[o] = np.arange(1, len(s) + 1)
    npos = y.sum(); nneg = len(y) - npos
    return float((r[y == 1].sum() - npos * (npos + 1) / 2) / (npos * nneg))
def metrics(traj, prob, y, mask=None):
    if mask is not None: traj, prob, y = traj[mask], prob[mask], y[mask]
    T = traj * SC; Y = y * SC
    d = np.linalg.norm(T - Y[:, None], axis=-1)            # (B,K,F)
    ade = d.mean(2); fde = d[..., -1]
    ml = np.argmax(prob, 1); ix = np.arange(len(y))
    lat_true = np.abs(Y[:, -1, 1]) > 1.75
    lat_pred = np.abs(T[ix, ml, -1, 1]) > 1.75
    p_y = (prob * (np.abs(T[:, :, -1, 1]) > 1.75)).sum(1)
    tp = (lat_pred & lat_true).sum(); P = tp / max(lat_pred.sum(), 1); R = tp / max(lat_true.sum(), 1)
    return dict(n=int(len(y)), ADE=float(ade[ix, ml].mean()), FDE=float(fde[ix, ml].mean()),
                minADE=float(ade.min(1).mean()), minFDE=float(fde.min(1).mean()),
                MR=float((fde.min(1) > 2.0).mean()), latFDE=float(np.abs(T[ix, ml, -1, 1] - Y[:, -1, 1]).mean()),
                P=float(P), R=float(R), F1=float(2 * P * R / max(P + R, 1e-9)),
                AUC=auc(p_y, lat_true.astype(int)) if lat_true.any() and (~lat_true).any() else float('nan'))
Z = dict(np.load(TEST))
res, preds = {}, {}
base = load(TEST, 'pace'); y = base['y']
# physics baselines
cv = base['prior'][:, None]
h = base['hist']; v = h[:, [2, 5, 8, 11]] * 20; a = np.clip((v[:, 3] - v[:, 2]) / 0.5, -4, 3)
t = 0.5 * np.arange(1, 7); xs = np.maximum(v[:, 3:4] * t + 0.5 * a[:, None] * t ** 2, 0) / 10
ca = np.stack([xs, np.zeros_like(xs)], -1)[:, None]
preds['CV'] = (cv, np.ones((len(y), 1))); preds['CA'] = (ca, np.ones((len(y), 1)))
lat = {}
for name, kind, K in [('MLP (K=1)', 'mlp', 1), ('Social-Attn (K=6)', 'social', 6), ('EVA-Net (K=1)', 'pace', 1), ('EVA-Net (K=6)', 'pace', 6)]:
    m = Predictor.load(f'{PFX}model_{kind}_K{K}.pkl'); D = load(TEST, kind)
    a_ = [D[k] for k in ('hist', 'ev', 'nb', 'mask', 'prior')]
    out = [m.predict(*[x[i:i + 4096] for x in a_]) for i in range(0, len(y), 4096)]
    preds[name] = (np.concatenate([o[0] for o in out]), np.concatenate([o[1] for o in out]))
    ts = []
    for r in range(30):
        i = r * 30; t0 = time.perf_counter(); m.predict(*[x[i:i + 30] for x in a_]); ts.append((time.perf_counter() - t0) * 1000)
    lat[name] = float(np.median(ts))
strata = {'EV-reacting': Z['reacted'] == 1 if 'reacted' in Z else None, 'not reacting': Z['reacted'] == 0 if 'reacted' in Z else None, 'all': None, 'near-EV': Z['near'] == 1, 'yielding (LC)': np.abs(y[:, -1, 1] * 3.5) > 1.75,
          'prompt': Z['driver'] == 0, 'late': Z['driver'] == 1, 'stubborn': Z['driver'] == 2, 'panic-brake': Z['freeze'] == 1}
for name, (tr, pr) in preds.items():
    res[name] = {s: metrics(tr, pr, y, m_) for s, m_ in strata.items()}
    res[name]['latency_ms_30agents'] = lat.get(name, 0.0)
json.dump(res, open(OUT, 'w'), indent=1)
for n in res: print(n, {k: round(v, 3) for k, v in res[n]['all'].items()}, res[n]['latency_ms_30agents'])
# qualitative example indices: yielding near-EV samples
np.save(OUT.replace('.json', '_examples.npy'), np.where((Z['near'] == 1) & (np.abs(y[:, -1, 1] * 3.5) > 1.75))[0][:200])
import pickle; pickle.dump({k: (v[0][:20000], v[1][:20000]) for k, v in preds.items()}, open(OUT.replace('.json', '_preds.pkl'), 'wb'))
