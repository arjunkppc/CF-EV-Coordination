# ns_ev — NS-EV reactive replay (from the NS-EV study)

Reactive log replay of nuScenes with an injected emergency vehicle, the driver-response model, and the
reactive-broadcast and PACE coordinators used as baselines. `coordination/` imports these modules and changes none of
them; the driver-model variants are applied at run time (`coordination/cl_variant.py`, `coordination/obey.py`).

| File | Role |
|---|---|
| `nsev_pipeline.py` | scene loading, EV injection, driver-response model (`RESP`), forecasting samples |
| `nsev_closedloop.py` | closed-loop replay (`Replay`), no coordination, reactive broadcast, PACE-CV / PACE-EVA |
| `train.py`, `eval_pred.py` | training and evaluation of the forecasters used by PACE |
| `features.py`, `sim.py`, `model.py`, `summarize_cl.py` | **add before publishing:** `bash tools/add_nsev_files.sh /path/to/nsev` |
