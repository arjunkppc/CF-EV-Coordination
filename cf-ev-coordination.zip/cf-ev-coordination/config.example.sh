# Copy to config.sh and edit. Every SLURM script in slurm/ sources this file.
export REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DATAROOT=/path/to/nuscenes          # nuScenes v1.0-trainval (annotations; sensor data not needed)
export PY=python                           # e.g. /apps/codes/anaconda2024/bin/python on our cluster
export NSEV_DIR="$REPO/ns_ev"              # NS-EV replay and coordinator code
export RUNS="$REPO/runs"                   # all outputs (*.jsonl, summaries, chosen_*.txt, model files)
export WORKERS=8                           # parallel replays per job
# Trained EVA-Net and Social-Attention forecasters from the NS-EV study (needed for PACE-EVA only)
export EVA="$RUNS/nsevdr_s0_model_pace_K6.pkl"
export SOC="$RUNS/nsevdr_s0_model_social_K6.pkl"
